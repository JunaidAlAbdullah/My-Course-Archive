#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void displayMatrix(int **graph, int n)
{
    printf("\nAdjacency Matrix (%d x %d):\n", n, n);

    printf("    ");
    for (int i = 0; i < n; i++)
    {
        printf("%3d ", i);
    }
    printf("\n");

    printf("    ");
    for (int i = 0; i < n; i++)
    {
        printf("----");
    }
    printf("\n");

    for (int i = 0; i < n; i++)
    {
        printf("%3d|", i);
        for (int j = 0; j < n; j++)
        {
            printf("%3d ", graph[i][j]);
        }
        printf("\n");
    }
}

void analyzeGraph(int n)
{
    int i, j;
    clock_t start, end;
    double cpu_time_used;
    int sumInDegrees = 0, sumOutDegrees = 0;

    printf("\n=== Analysis for Graph with %d vertices ===\n", n);

    printf("\nStep 1: Creating the graph...\n");
    int **graph = (int **)malloc(n * sizeof(int *));
    int *inDegrees = (int *)calloc(n, sizeof(int));
    int *outDegrees = (int *)calloc(n, sizeof(int));

    for (i = 0; i < n; i++)
    {
        graph[i] = (int *)malloc(n * sizeof(int));
    }
    
    srand(time(NULL) + n);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i != j)
            {
                graph[i][j] = rand() % 2;
            }
            else
            {
                graph[i][j] = 0;
            }
        }
    }

    if (n <= 10)
    {
        displayMatrix(graph, n);
    }
    else
    {
        printf("\nMatrix is too large to display (%d x %d)\n", n, n);
    }

    printf("\nStep 2: Calculating degrees...\n");
    start = clock();

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (graph[i][j] == 1)
            {
                outDegrees[i]++;
                inDegrees[j]++;
            }
        }
    }

    for (i = 0; i < n; i++)
    {
        sumInDegrees += inDegrees[i];
        sumOutDegrees += outDegrees[i];
    }

    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC * 1000;

    if (n <= 10)
    {
        printf("\nVertex  In-Degree  Out-Degree\n");
        printf("------------------------------\n");
        for (i = 0; i < n; i++)
        {
            printf("%3d %8d %11d\n", i, inDegrees[i], outDegrees[i]);
        }
    }

    printf("\nResults:\n");
    printf("- Sum of in-degrees: %d\n", sumInDegrees);
    printf("- Sum of out-degrees: %d\n", sumOutDegrees);
    printf("- Computation time: %.2f milliseconds\n", cpu_time_used);

    if (sumInDegrees == sumOutDegrees)
    {
        printf("\nVerification: Sum of in-degrees equals sum of out-degrees (*)\n");
    }

    for (i = 0; i < n; i++)
    {
        free(graph[i]);
    }
    free(graph);
    free(inDegrees);
    free(outDegrees);
}

int main()
{
    int n;
    char choice = 'y';

    printf("Graph Analysis Program\n");
    printf("=====================\n");

    while (choice == 'y' || choice == 'Y')
    {
        printf("\nEnter the number of vertices (1-5000): ");
        while (scanf("%d", &n) != 1 || n < 1 || n > 5000)
        {
            while (getchar() != '\n')
                ;
            printf("Invalid input! Please enter a number between 1 and 5000: ");
        }

        while (getchar() != '\n')
            ;

        analyzeGraph(n);

        printf("\nDo you want to analyze another graph? (y/n): ");
        scanf(" %c", &choice);
        while (getchar() != '\n')
            ;
    }

    printf("\nThank you for using the Graph Analysis Program!\n");
    return 0;
}