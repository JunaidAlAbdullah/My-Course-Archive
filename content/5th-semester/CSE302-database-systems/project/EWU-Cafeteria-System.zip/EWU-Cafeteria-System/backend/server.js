/**
 * EWU Cafeteria Pre-Order System
 * Main Backend Server File
 * Uses: Express.js, MySQL2, JWT Authentication
 */

const express = require('express');
const cors = require('cors');
const session = require('express-session');
const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// ===== MIDDLEWARE =====

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS configuration
app.use(cors({
    origin: 'http://localhost:5500', // Frontend port
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'ewu_cafeteria_secret_key_2024',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// ===== REQUEST LOGGING MIDDLEWARE =====

// Log all incoming requests
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// ===== DATABASE CONNECTION POOL =====

// Create MySQL connection pool
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'ewu_cafeteria_project',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Export pool for use in routes
app.locals.pool = pool;

// ===== DATABASE CONNECTION HEALTH CHECK =====

// Check database on startup only, don't hold connections
pool.getConnection()
    .then(conn => {
        console.log('[DATABASE] Connection pool initialized and tested successfully');
        conn.release();
    })
    .catch(err => {
        console.error('[DATABASE ERROR] Failed to connect to database:', err.message);
        process.exit(1);
    });

// ===== ROUTES =====

// Import route modules
const authRoutes = require('./routes/auth');
const studentRoutes = require('./routes/students');
const foodRoutes = require('./routes/foods');
const orderRoutes = require('./routes/orders');
const adminRoutes = require('./routes/admin');
const staffRoutes = require('./routes/staff');
const notificationRoutes = require('./routes/notifications');
const complaintRoutes = require('./routes/complaints');

// Register routes with API prefix
app.use('/api/auth', authRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/foods', foodRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/complaints', complaintRoutes);

// ===== STATIC FILES =====

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// ===== ROOT ROUTE =====

app.get('/', (req, res) => {
    res.json({
        message: 'EWU Cafeteria Pre-Order System API',
        version: '1.0.0',
        status: 'Running',
        endpoints: {
            auth: '/api/auth',
            students: '/api/students',
            foods: '/api/foods',
            orders: '/api/orders',
            admin: '/api/admin',
            staff: '/api/staff',
            notifications: '/api/notifications'
        }
    });
});

// ===== ERROR HANDLING MIDDLEWARE =====

// 404 Not Found
app.use((req, res) => {
    res.status(404).json({ error: 'Route not found' });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({
        error: err.message || 'Internal Server Error',
        ...(process.env.NODE_ENV === 'development' && { details: err })
    });
});

// ===== START SERVER =====

const server = app.listen(PORT, () => {
    console.log(`
  ╔════════════════════════════════════════════════════════╗
  ║   EWU Cafeteria Pre-Order System - Backend Server      ║
  ║   Server running on: http://localhost:${PORT}           ║
  ║   Environment: ${process.env.NODE_ENV || 'development'}                          ║
  ║   Database: ${process.env.DB_NAME || 'ewu_cafeteria'}                            ║
  ╚════════════════════════════════════════════════════════╝
  `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received: closing HTTP server');
    server.close(async () => {
        await pool.end();
        console.log('HTTP server closed. Database pool closed.');
        process.exit(0);
    });
});

module.exports = app;
