/**
 * Student Routes
 * Handles student profile and feedback
 */

const express = require('express');
const { verifyToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// ===== GET STUDENT PROFILE =====

/**
 * GET /api/students/profile
 * Get logged-in student's profile
 */
router.get('/profile', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Get student info
        const [students] = await pool.query(
            `SELECT s.student_id, s.user_id, s.student_name, s.student_number, 
              s.department, s.semester, s.total_orders, s.loyalty_points,
              s.profile_picture_url, s.created_at,
              u.email, u.phone
       FROM Students s
       JOIN Users u ON s.user_id = u.user_id
       WHERE s.user_id = ?`,
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        res.json({
            success: true,
            data: students[0]
        });
    } catch (error) {
        console.error('Get student profile error:', error);
        res.status(500).json({ error: 'Failed to fetch profile' });
    }
});

// ===== UPDATE STUDENT PROFILE =====

/**
 * PUT /api/students/profile
 * Update student profile
 */
router.put('/profile', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { student_name, phone, profile_picture_url } = req.body;

        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            // Update user table
            if (phone) {
                await connection.query(
                    'UPDATE Users SET phone = ? WHERE user_id = ?',
                    [phone, req.user.userId]
                );
            }

            // Update student table
            const updateFields = [];
            const params = [];

            if (student_name) {
                updateFields.push('student_name = ?');
                params.push(student_name);
            }

            if (profile_picture_url) {
                updateFields.push('profile_picture_url = ?');
                params.push(profile_picture_url);
            }

            if (updateFields.length > 0) {
                params.push(req.user.userId);
                await connection.query(
                    `UPDATE Students SET ${updateFields.join(', ')} WHERE user_id = ?`,
                    params
                );
            }

            await connection.commit();

            res.json({
                success: true,
                message: 'Profile updated successfully'
            });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
});

// ===== SUBMIT COMPLAINT =====

/**
 * POST /api/students/complaints
 * Submit a complaint
 */
router.post('/complaints', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { complaint_type_id, subject, description, order_id, attachment_url } = req.body;

        // Validation
        if (!complaint_type_id || !subject || !description) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        // Get student
        const [students] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student_id = students[0].student_id;

        // Create complaint
        const [result] = await pool.query(
            `INSERT INTO Complaints (student_id, order_id, complaint_type_id, subject, description, attachment_url, status, priority)
       VALUES (?, ?, ?, ?, ?, ?, 'Open', 'Medium')`,
            [student_id, order_id || null, complaint_type_id, subject, description, attachment_url || null]
        );

        // Create notification for admin
        const [admins] = await pool.query(
            'SELECT user_id FROM Admins LIMIT 1'
        );

        if (admins.length > 0) {
            await pool.query(
                'INSERT INTO Notifications (user_id, notification_type, title, message, related_order_id) VALUES (?, ?, ?, ?, ?)',
                [admins[0].user_id, 'New Complaint', `New Complaint: ${subject}`, `Student submitted a new complaint: ${description.substring(0, 50)}...`, order_id || null]
            );
        }

        res.status(201).json({
            success: true,
            message: 'Complaint submitted successfully',
            data: {
                complaint_id: result.insertId,
                status: 'Open'
            }
        });
    } catch (error) {
        console.error('Submit complaint error:', error);
        res.status(500).json({ error: 'Failed to submit complaint' });
    }
});

// ===== GET STUDENT COMPLAINTS =====

/**
 * GET /api/students/complaints
 * Get all complaints submitted by student
 */
router.get('/complaints', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Get student
        const [students] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student_id = students[0].student_id;

        // Get complaints
        const [complaints] = await pool.query(
            `SELECT c.complaint_id, c.subject, c.description, ct.type_name, 
              c.status, c.priority, c.resolution_notes, c.created_at, c.resolved_date
       FROM Complaints c
       JOIN ComplaintTypes ct ON c.complaint_type_id = ct.type_id
       WHERE c.student_id = ?
       ORDER BY c.created_at DESC`,
            [student_id]
        );

        res.json({
            success: true,
            data: complaints
        });
    } catch (error) {
        console.error('Get complaints error:', error);
        res.status(500).json({ error: 'Failed to fetch complaints' });
    }
});

// ===== SUBMIT FEEDBACK =====

/**
 * POST /api/students/feedback
 * Submit general feedback
 */
router.post('/feedback', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { subject, message, rating, order_id } = req.body;

        // Validation
        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        // Get student
        const [students] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student_id = students[0].student_id;

        // Create feedback
        const [result] = await pool.query(
            `INSERT INTO Feedback (student_id, order_id, subject, message, rating)
       VALUES (?, ?, ?, ?, ?)`,
            [student_id, order_id || null, subject || null, message, rating || null]
        );

        res.status(201).json({
            success: true,
            message: 'Feedback submitted successfully',
            data: {
                feedback_id: result.insertId
            }
        });
    } catch (error) {
        console.error('Submit feedback error:', error);
        res.status(500).json({ error: 'Failed to submit feedback' });
    }
});

// ===== GET STUDENT STATISTICS =====

/**
 * GET /api/students/stats
 * Get student order statistics
 */
router.get('/stats', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Get student
        const [students] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student_id = students[0].student_id;

        // Get statistics
        const [stats] = await pool.query(
            `SELECT 
         COUNT(*) as total_orders,
         SUM(total_amount) as total_spent,
         AVG(total_amount) as avg_order_value,
         COUNT(CASE WHEN DATE(order_date) = DATE(NOW()) THEN 1 END) as today_orders
       FROM Orders
       WHERE student_id = ?`,
            [student_id]
        );

        // Get order breakdown by status
        const [statusBreakdown] = await pool.query(
            `SELECT os.status_name, COUNT(*) as count
       FROM Orders o
       JOIN OrderStatus os ON o.status_id = os.status_id
       WHERE o.student_id = ?
       GROUP BY o.status_id, os.status_name`,
            [student_id]
        );

        res.json({
            success: true,
            data: {
                summary: stats[0],
                statusBreakdown
            }
        });
    } catch (error) {
        console.error('Get statistics error:', error);
        res.status(500).json({ error: 'Failed to fetch statistics' });
    }
});

module.exports = router;
