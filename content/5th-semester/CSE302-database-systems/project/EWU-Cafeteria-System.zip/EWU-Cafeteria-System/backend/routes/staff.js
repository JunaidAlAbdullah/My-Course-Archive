/**
 * Staff Routes
 * Handles kitchen staff operations
 */

const express = require('express');
const { verifyToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// ===== CREATE TEST ORDER FOR STAFF =====

/**
 * POST /api/staff/test-order
 * Create a test order for demonstration
 */
router.post('/test-order', verifyToken, requireRole('Staff'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        
        // Get first student
        const [students] = await pool.query('SELECT student_id FROM Students LIMIT 1');
        if (students.length === 0) {
            return res.status(400).json({ error: 'No students found' });
        }
        
        const student_id = students[0].student_id;
        
        // Create order with pending status
        const [orderResult] = await pool.query(
            `INSERT INTO Orders (student_id, order_date, order_time, status_id, total_amount, payment_status, payment_method, special_instructions)
             VALUES (?, DATE(NOW()), TIME(NOW()), 1, 150.00, 'Pending', 'Cash', 'Test order for kitchen')`,
            [student_id]
        );
        
        const order_id = orderResult.insertId;
        
        // Add order details
        await pool.query(
            'INSERT INTO OrderDetails (order_id, food_id, quantity, price_at_order) VALUES (?, 1, 2, 40), (?, 6, 1, 120)',
            [order_id, order_id]
        );
        
        res.json({
            success: true,
            message: 'Test order created',
            data: { order_id }
        });
    } catch (error) {
        console.error('Create test order error:', error);
        res.status(500).json({ error: 'Failed to create test order' });
    }
});

// ===== GET ASSIGNED ORDERS =====

/**
 * GET /api/staff/orders
 * Get orders assigned to staff
 */
router.get('/orders', verifyToken, requireRole('Staff'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { status_id } = req.query;

        let query = `SELECT o.order_id, o.student_id, s.student_name,
                        o.order_date, o.order_time, ts.slot_time,
                        o.status_id, os.status_name, o.special_instructions,
                        o.created_at
                 FROM Orders o
                 JOIN Students s ON o.student_id = s.student_id
                 LEFT JOIN TimeSlots ts ON o.slot_id = ts.slot_id
                 JOIN OrderStatus os ON o.status_id = os.status_id`;

        const params = [];

        // Show orders that are Pending (1), Confirmed (2), Preparing (3), or Ready (4)
        query += ' WHERE o.status_id IN (1, 2, 3, 4)';

        if (status_id) {
            query += ' AND o.status_id = ?';
            params.push(status_id);
        }

        query += ' ORDER BY o.created_at ASC';

        const [orders] = await pool.query(query, params);

        // Get items for each order
        for (let order of orders) {
            const [items] = await pool.query(
                `SELECT od.order_detail_id, od.food_id, f.food_name,
                od.quantity, od.special_notes
         FROM OrderDetails od
         JOIN FoodItems f ON od.food_id = f.food_id
         WHERE od.order_id = ?`,
                [order.order_id]
            );
            order.items = items;
        }

        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Get assigned orders error:', error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
});

// ===== UPDATE ORDER STATUS =====

/**
 * PATCH /api/staff/orders/:order_id/status
 * Update order status (Preparing -> Ready -> Served)
 */
router.patch('/orders/:order_id/status', verifyToken, requireRole('Staff'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { order_id } = req.params;
        const { status_id } = req.body;

        if (!status_id) {
            return res.status(400).json({ error: 'Status ID required' });
        }

        // Staff can only move to Preparing, Ready, or Served status
        if (![3, 4, 5].includes(parseInt(status_id))) {
            return res.status(400).json({ error: 'Invalid status for staff' });
        }

        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            // Update order status
            await connection.query(
                'UPDATE Orders SET status_id = ? WHERE order_id = ?',
                [status_id, order_id]
            );

            // Get order and create notification
            const [orders] = await connection.query(
                'SELECT student_id FROM Orders WHERE order_id = ?',
                [order_id]
            );

            if (orders.length > 0) {
                const [students] = await connection.query(
                    'SELECT user_id FROM Students WHERE student_id = ?',
                    [orders[0].student_id]
                );

                if (students.length > 0) {
                    const [statuses] = await connection.query(
                        'SELECT status_name FROM OrderStatus WHERE status_id = ?',
                        [status_id]
                    );

                    const statusName = statuses.length > 0 ? statuses[0].status_name : 'Updated';

                    let notifyMessage = `Your order #${order_id} is now ${statusName.toLowerCase()}`;

                    if (statusName === 'Ready') {
                        notifyMessage = `Your order #${order_id} is ready for pickup!`;
                    }

                    await connection.query(
                        'INSERT INTO Notifications (user_id, notification_type, title, message, related_order_id) VALUES (?, ?, ?, ?, ?)',
                        [students[0].user_id, 'Order Status', `Order #${order_id} ${statusName}`, notifyMessage, order_id]
                    );
                }
            }

            await connection.commit();

            res.json({
                success: true,
                message: 'Order status updated successfully'
            });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('Update order status error:', error);
        res.status(500).json({ error: 'Failed to update order' });
    }
});

/**
 * GET /api/staff/dashboard
 * Get staff dashboard with workload
 */
router.get('/dashboard', verifyToken, requireRole('Staff'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Orders in preparation
        const [preparing] = await pool.query(
            'SELECT COUNT(*) as count FROM Orders WHERE status_id = 3'
        );

        // Orders ready
        const [ready] = await pool.query(
            'SELECT COUNT(*) as count FROM Orders WHERE status_id = 4'
        );

        // Pending orders (today)
        const [pending] = await pool.query(
            "SELECT COUNT(*) as count FROM Orders WHERE DATE(order_date) = DATE(NOW()) AND status_id = 2"
        );

        // Recent orders
        const [recentOrders] = await pool.query(
            `SELECT o.order_id, s.student_name, o.status_id, os.status_name
       FROM Orders o
       JOIN Students s ON o.student_id = s.student_id
       JOIN OrderStatus os ON o.status_id = os.status_id
       WHERE o.status_id IN (2, 3, 4)
       ORDER BY o.created_at DESC
       LIMIT 10`
        );

        res.json({
            success: true,
            data: {
                preparing: preparing[0],
                ready: ready[0],
                pending: pending[0],
                recentOrders
            }
        });
    } catch (error) {
        console.error('Get staff dashboard error:', error);
        res.status(500).json({ error: 'Failed to fetch dashboard' });
    }
});

module.exports = router;
