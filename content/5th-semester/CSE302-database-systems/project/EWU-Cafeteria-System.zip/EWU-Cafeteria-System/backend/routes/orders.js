/**
 * Orders Routes
 * Handles order creation, tracking, and management
 */

const express = require('express');
const { verifyToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// ===== GET ALL TIME SLOTS =====

/**
 * GET /api/orders/slots
 * Get available time slots for pickup
 */
router.get('/slots', async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        const [slots] = await pool.query(
            'SELECT slot_id, slot_time, available_capacity, current_orders, is_active FROM TimeSlots WHERE is_active = TRUE ORDER BY slot_id'
        );

        res.json({
            success: true,
            data: slots
        });
    } catch (error) {
        console.error('Get slots error:', error);
        res.status(500).json({ error: 'Failed to fetch time slots' });
    }
});

// ===== PLACE NEW ORDER =====

/**
 * POST /api/orders
 * Create new order (Student)
 * Body: { items: [{food_id, quantity}, ...], payment_method, special_instructions }
 */
router.post('/', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { items, payment_method, special_instructions } = req.body;

        // Validation
        if (!items || items.length === 0) {
            return res.status(400).json({ error: 'Invalid order data' });
        }

        // Get student
        const [students] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student_id = students[0].student_id;

        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            // Calculate total amount and verify items
            let totalAmount = 0;
            const itemDetails = [];

            for (const item of items) {
                const [foods] = await connection.query(
                    'SELECT food_id, price, availability_status FROM FoodItems WHERE food_id = ?',
                    [item.food_id]
                );

                if (foods.length === 0 || !foods[0].availability_status) {
                    throw new Error(`Food item ${item.food_id} not available`);
                }

                const itemTotal = foods[0].price * item.quantity;
                totalAmount += itemTotal;
                itemDetails.push({
                    food_id: item.food_id,
                    quantity: item.quantity,
                    price_at_order: foods[0].price
                });
            }

            // Create order (no slot_id required)
            const [orderResult] = await connection.query(
                `INSERT INTO Orders (student_id, order_date, order_time, status_id, total_amount, payment_status, payment_method, special_instructions)
         VALUES (?, DATE(NOW()), TIME(NOW()), 1, ?, 'Pending', ?, ?)`,
                [student_id, totalAmount, payment_method || 'Cash', special_instructions || null]
            );

            const order_id = orderResult.insertId;

            // Insert order details
            for (const detail of itemDetails) {
                await connection.query(
                    'INSERT INTO OrderDetails (order_id, food_id, quantity, price_at_order) VALUES (?, ?, ?, ?)',
                    [order_id, detail.food_id, detail.quantity, detail.price_at_order]
                );

                // Update food item quantity (decrement stock)
                await connection.query(
                    'UPDATE FoodItems SET quantity_available = quantity_available - ? WHERE food_id = ?',
                    [detail.quantity, detail.food_id]
                );
            }

            // Update student total orders
            await connection.query(
                'UPDATE Students SET total_orders = total_orders + 1 WHERE student_id = ?',
                [student_id]
            );

            // Create notification
            const [studentUser] = await connection.query(
                'SELECT user_id FROM Students WHERE student_id = ?',
                [student_id]
            );

            if (studentUser.length > 0) {
                await connection.query(
                    'INSERT INTO Notifications (user_id, notification_type, title, message, related_order_id) VALUES (?, ?, ?, ?, ?)',
                    [studentUser[0].user_id, 'Order Placed', 'Order Placed Successfully', `Your order #${order_id} has been placed. Total: ৳${totalAmount}`, order_id]
                );
            }

            await connection.commit();

            res.status(201).json({
                success: true,
                message: 'Order placed successfully',
                data: {
                    order_id,
                    total_amount: totalAmount,
                    payment_method,
                    status: 'Pending',
                    created_at: new Date()
                }
            });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('Place order error:', error);
        res.status(500).json({ error: error.message || 'Failed to place order' });
    }
});

// ===== GET STUDENT ORDERS =====

/**
 * GET /api/orders/my-orders
 * Get all orders of logged-in student
 */
router.get('/my-orders', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Get student
        const [students] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student_id = students[0].student_id;

        // Get orders
        const [orders] = await pool.query(
            `SELECT o.order_id, o.order_date, o.order_time,
              o.status_id, os.status_name, o.total_amount, o.payment_status,
              o.payment_method, o.special_instructions, o.created_at
       FROM Orders o
       JOIN OrderStatus os ON o.status_id = os.status_id
       WHERE o.student_id = ?
       ORDER BY o.created_at DESC
       LIMIT 50`,
            [student_id]
        );

        // Get order details for each order
        for (let order of orders) {
            const [details] = await pool.query(
                `SELECT od.order_detail_id, od.food_id, f.food_name, f.image_url,
                od.quantity, od.price_at_order
         FROM OrderDetails od
         JOIN FoodItems f ON od.food_id = f.food_id
         WHERE od.order_id = ?`,
                [order.order_id]
            );
            order.items = details;
        }

        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Get student orders error:', error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
});

// ===== GET SINGLE ORDER =====

/**
 * GET /api/orders/:order_id
 * Get single order details
 */
router.get('/:order_id', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { order_id } = req.params;

        // Get order
        const [orders] = await pool.query(
            `SELECT o.order_id, o.student_id, o.order_date, o.order_time,
              o.status_id, os.status_name, o.total_amount, o.payment_status,
              o.payment_method, o.special_instructions, o.created_at
       FROM Orders o
       JOIN OrderStatus os ON o.status_id = os.status_id
       WHERE o.order_id = ?`,
            [order_id]
        );

        if (orders.length === 0) {
            return res.status(404).json({ error: 'Order not found' });
        }

        const order = orders[0];

        // Check authorization for students
        if (req.user.role === 'Student') {
            const [students] = await pool.query(
                'SELECT student_id FROM Students WHERE user_id = ?',
                [req.user.userId]
            );

            if (students.length === 0 || students[0].student_id !== order.student_id) {
                return res.status(403).json({ error: 'Unauthorized' });
            }
        }

        // Get order items
        const [details] = await pool.query(
            `SELECT od.order_detail_id, od.food_id, f.food_name, f.image_url,
              od.quantity, od.price_at_order
       FROM OrderDetails od
       JOIN FoodItems f ON od.food_id = f.food_id
       WHERE od.order_id = ?`,
            [order_id]
        );

        order.items = details;

        res.json({
            success: true,
            data: order
        });
    } catch (error) {
        console.error('Get order error:', error);
        res.status(500).json({ error: 'Failed to fetch order' });
    }
});

// ===== CANCEL ORDER =====

/**
 * PATCH /api/orders/:order_id/cancel
 * Cancel order (only if status is Pending or Confirmed)
 */
router.patch('/:order_id/cancel', verifyToken, requireRole('Student'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { order_id } = req.params;

        // Get student
        const [students] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (students.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student_id = students[0].student_id;

        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            // Get order
            const [orders] = await connection.query(
                `SELECT o.order_id, o.student_id, o.status_id, o.slot_id
         FROM Orders o
         WHERE o.order_id = ?`,
                [order_id]
            );

            if (orders.length === 0) {
                throw new Error('Order not found');
            }

            const order = orders[0];

            // Check authorization
            if (order.student_id !== student_id) {
                throw new Error('Unauthorized');
            }

            // Check status - can only cancel pending/confirmed orders
            if (order.status_id > 2) {
                throw new Error('Cannot cancel order at this stage');
            }

            // Update order status to Cancelled (status_id = 6)
            await connection.query(
                'UPDATE Orders SET status_id = 6 WHERE order_id = ?',
                [order_id]
            );

            // Release slot
            await connection.query(
                'UPDATE TimeSlots SET current_orders = current_orders - 1 WHERE slot_id = ?',
                [order.slot_id]
            );

            await connection.commit();

            res.json({
                success: true,
                message: 'Order cancelled successfully'
            });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('Cancel order error:', error);
        res.status(500).json({ error: error.message || 'Failed to cancel order' });
    }
});

module.exports = router;
