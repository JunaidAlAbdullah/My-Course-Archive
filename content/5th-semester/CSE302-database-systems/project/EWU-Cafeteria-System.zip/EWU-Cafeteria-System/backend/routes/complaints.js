/**
 * Complaints Routes
 * Handles user complaints
 */

const express = require('express');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

// ===== GET COMPLAINT TYPES =====

router.get('/types', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        const [types] = await pool.query(
            'SELECT type_id, type_name FROM ComplaintTypes ORDER BY type_name'
        );

        res.json({
            success: true,
            data: types
        });
    } catch (error) {
        console.error('Get complaint types error:', error);
        res.status(500).json({ error: 'Failed to fetch complaint types' });
    }
});

// ===== GET USER COMPLAINTS =====

router.get('/', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        const [complaints] = await pool.query(
            `SELECT c.complaint_id, c.subject, c.description, c.status, 
                    c.priority, c.created_at, ct.type_name
             FROM Complaints c
             JOIN ComplaintTypes ct ON c.complaint_type_id = ct.type_id
             JOIN Students s ON c.student_id = s.student_id
             WHERE s.user_id = ?
             ORDER BY c.created_at DESC`,
            [req.user.userId]
        );

        res.json({
            success: true,
            data: complaints
        });
    } catch (error) {
        console.error('Get complaints error:', error);
        res.status(500).json({ error: 'Failed to fetch complaints' });
    }
});

// ===== CREATE COMPLAINT =====

router.post('/', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { complaint_type_id, subject, description, order_id } = req.body;

        // Get student_id
        const [studentResult] = await pool.query(
            'SELECT student_id FROM Students WHERE user_id = ?',
            [req.user.userId]
        );

        if (studentResult.length === 0) {
            return res.status(400).json({ error: 'Student profile not found' });
        }

        const student_id = studentResult[0].student_id;

        const [result] = await pool.query(
            `INSERT INTO Complaints (student_id, complaint_type_id, subject, description, order_id)
             VALUES (?, ?, ?, ?, ?)`,
            [student_id, complaint_type_id, subject, description, order_id || null]
        );

        res.json({
            success: true,
            complaint_id: result.insertId,
            message: 'Complaint filed successfully'
        });
    } catch (error) {
        console.error('Create complaint error:', error);
        res.status(500).json({ error: 'Failed to file complaint' });
    }
});

// ===== GET COMPLAINT DETAILS =====

router.get('/:complaint_id', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { complaint_id } = req.params;

        const [complaint] = await pool.query(
            `SELECT c.*, ct.type_name
             FROM Complaints c
             JOIN ComplaintTypes ct ON c.complaint_type_id = ct.type_id
             JOIN Students s ON c.student_id = s.student_id
             WHERE c.complaint_id = ? AND s.user_id = ?`,
            [complaint_id, req.user.userId]
        );

        if (complaint.length === 0) {
            return res.status(404).json({ error: 'Complaint not found' });
        }

        res.json({
            success: true,
            data: complaint[0]
        });
    } catch (error) {
        console.error('Get complaint error:', error);
        res.status(500).json({ error: 'Failed to fetch complaint' });
    }
});

// ===== UPDATE COMPLAINT =====

router.put('/:complaint_id', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { complaint_id } = req.params;
        const { subject, description } = req.body;

        const [complaint] = await pool.query(
            `SELECT c.complaint_id FROM Complaints c
             JOIN Students s ON c.student_id = s.student_id
             WHERE c.complaint_id = ? AND s.user_id = ?`,
            [complaint_id, req.user.userId]
        );

        if (complaint.length === 0) {
            return res.status(404).json({ error: 'Complaint not found' });
        }

        await pool.query(
            `UPDATE Complaints SET subject = ?, description = ? WHERE complaint_id = ?`,
            [subject, description, complaint_id]
        );

        res.json({
            success: true,
            message: 'Complaint updated'
        });
    } catch (error) {
        console.error('Update complaint error:', error);
        res.status(500).json({ error: 'Failed to update complaint' });
    }
});

module.exports = router;
