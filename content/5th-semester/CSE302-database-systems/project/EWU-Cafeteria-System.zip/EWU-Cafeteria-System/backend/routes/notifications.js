/**
 * Notifications Routes
 * Handles user notifications
 */

const express = require('express');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

// ===== GET UNREAD COUNT =====
// NOTE: Placed before generic routes to avoid route conflicts

/**
 * GET /api/notifications/count/unread
 * Get unread notification count
 */
router.get('/count/unread', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        const [result] = await pool.query(
            'SELECT COUNT(*) as count FROM Notifications WHERE user_id = ? AND is_read = FALSE',
            [req.user.userId]
        );

        res.json({
            success: true,
            count: result[0].count
        });
    } catch (error) {
        console.error('Get unread count error:', error);
        res.status(500).json({ error: 'Failed to fetch count' });
    }
});

// ===== MARK ALL AS READ =====
// NOTE: Placed before generic :notification_id routes to avoid route conflicts

/**
 * PATCH /api/notifications/read-all
 * Mark all notifications as read
 */
router.patch('/read-all', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        await pool.query(
            'UPDATE Notifications SET is_read = TRUE WHERE user_id = ? AND is_read = FALSE',
            [req.user.userId]
        );

        res.json({
            success: true,
            message: 'All notifications marked as read'
        });
    } catch (error) {
        console.error('Mark all read error:', error);
        res.status(500).json({ error: 'Failed to update notifications' });
    }
});

// ===== GET USER NOTIFICATIONS =====

/**
 * GET /api/notifications
 * Get all notifications for user
 */
router.get('/', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { limit = 20, offset = 0 } = req.query;

        const [notifications] = await pool.query(
            `SELECT notification_id, notification_type, title, message, is_read, 
              related_order_id, created_at
       FROM Notifications
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`,
            [req.user.userId, parseInt(limit), parseInt(offset)]
        );

        // Get unread count
        const [unreadCount] = await pool.query(
            'SELECT COUNT(*) as count FROM Notifications WHERE user_id = ? AND is_read = FALSE',
            [req.user.userId]
        );

        res.json({
            success: true,
            data: notifications,
            unreadCount: unreadCount[0].count
        });
    } catch (error) {
        console.error('Get notifications error:', error);
        res.status(500).json({ error: 'Failed to fetch notifications' });
    }
});

// ===== MARK NOTIFICATION AS READ =====

/**
 * PATCH /api/notifications/:notification_id/read
 * Mark notification as read
 */
router.patch('/:notification_id/read', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { notification_id } = req.params;

        await pool.query(
            'UPDATE Notifications SET is_read = TRUE WHERE notification_id = ? AND user_id = ?',
            [notification_id, req.user.userId]
        );

        res.json({
            success: true,
            message: 'Notification marked as read'
        });
    } catch (error) {
        console.error('Mark read error:', error);
        res.status(500).json({ error: 'Failed to update notification' });
    }
});

// ===== DELETE NOTIFICATION =====

/**
 * DELETE /api/notifications/:notification_id
 * Delete a notification
 */
router.delete('/:notification_id', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { notification_id } = req.params;

        const [result] = await pool.query(
            'DELETE FROM Notifications WHERE notification_id = ? AND user_id = ?',
            [notification_id, req.user.userId]
        );

        // Check if any rows were affected
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                error: 'Notification not found or already deleted'
            });
        }

        res.json({
            success: true,
            message: 'Notification deleted'
        });
    } catch (error) {
        console.error('Delete notification error:', error);
        res.status(500).json({ error: 'Failed to delete notification' });
    }
});

module.exports = router;
