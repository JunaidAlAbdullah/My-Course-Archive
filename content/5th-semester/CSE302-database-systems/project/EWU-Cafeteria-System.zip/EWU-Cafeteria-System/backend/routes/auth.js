/**
 * Authentication Routes
 * Handles user registration and login
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const { generateToken, verifyToken } = require('../middleware/auth');

const router = express.Router();

// ===== REGISTER ROUTE =====

/**
 * POST /api/auth/register
 * Register new user (Student)
 */
router.post('/register', async (req, res) => {
    try {
        console.log('[AUTH-REGISTER] POST /api/auth/register');
        console.log('[AUTH-REGISTER] Request body:', req.body);

        const { email, password, phone, student_name, student_number, department } = req.body;

        // Validation
        if (!email || !password || !student_name || !student_number) {
            console.error('[AUTH-REGISTER] Missing required fields:', { email, password, student_name, student_number });
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const pool = req.app.locals.pool;
        console.log('[AUTH-REGISTER] Pool acquired, checking for existing users...');

        // Check if email already exists
        const [existingUser] = await pool.query(
            'SELECT user_id FROM Users WHERE email = ?',
            [email]
        );

        if (existingUser.length > 0) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        // Check if student number already exists
        const [existingStudent] = await pool.query(
            'SELECT student_id FROM Students WHERE student_number = ?',
            [student_number]
        );

        if (existingStudent.length > 0) {
            return res.status(400).json({ error: 'Student number already registered' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Start transaction
        const connection = await pool.getConnection();
        await connection.beginTransaction();

        try {
            // Create user
            const [userResult] = await connection.query(
                'INSERT INTO Users (email, password_hash, phone) VALUES (?, ?, ?)',
                [email, hashedPassword, phone || null]
            );

            const userId = userResult.insertId;

            // Assign Student role (role_id = 1)
            await connection.query(
                'INSERT INTO User_Roles (user_id, role_id) VALUES (?, 1)',
                [userId]
            );

            // Create student record
            await connection.query(
                'INSERT INTO Students (user_id, student_name, student_number, department) VALUES (?, ?, ?, ?)',
                [userId, student_name, student_number, department || null]
            );

            await connection.commit();
            console.log('[AUTH-REGISTER] Transaction committed successfully for user:', userId);

            // Generate token
            const token = generateToken({
                user_id: userId,
                email: email,
                role: 'Student'
            });

            console.log('[AUTH-REGISTER] Registration successful, token generated');

            res.status(201).json({
                success: true,
                message: 'Registration successful',
                token,
                user: {
                    userId,
                    email,
                    student_name,
                    role: 'Student'
                }
            });
        } catch (error) {
            console.error('[AUTH-REGISTER] Transaction error:', error);
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('[AUTH-REGISTER] Critical error:', error.message);
        console.error('[AUTH-REGISTER] Error stack:', error.stack);
        res.status(500).json({
            error: 'Registration failed',
            details: error.message,
            ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
        });
    }
});

// ===== LOGIN ROUTE =====

/**
 * POST /api/auth/login
 * Login user
 */
router.post('/login', async (req, res) => {
    try {
        console.log('[AUTH-LOGIN] POST /api/auth/login');
        console.log('[AUTH-LOGIN] Request body:', { email: req.body.email, password: '***hidden***' });

        const { email, password } = req.body;

        // Validation
        if (!email || !password) {
            console.error('[AUTH-LOGIN] Missing email or password');
            return res.status(400).json({ error: 'Email and password required' });
        }

        const pool = req.app.locals.pool;

        // Get user
        const [users] = await pool.query(
            'SELECT u.user_id, u.email, u.password_hash FROM Users u WHERE u.email = ?',
            [email]
        );

        if (users.length === 0) {
            console.error('[AUTH-LOGIN] User not found:', email);
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        console.log('[AUTH-LOGIN] User found:', email);

        const user = users[0];

        // Verify password
        const passwordMatch = await bcrypt.compare(password, user.password_hash);

        if (!passwordMatch) {
            console.error('[AUTH-LOGIN] Password mismatch for:', email);
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        console.log('[AUTH-LOGIN] Password verified for:', email);

        // Get user role
        const [roles] = await pool.query(
            `SELECT r.role_name FROM User_Roles ur 
       JOIN Roles r ON ur.role_id = r.role_id 
       WHERE ur.user_id = ?`,
            [user.user_id]
        );

        const userRole = roles.length > 0 ? roles[0].role_name : 'Student';
        console.log('[AUTH-LOGIN] User role:', userRole);

        // Generate token
        const token = generateToken({
            user_id: user.user_id,
            email: user.email,
            role: userRole
        });

        // Get user details based on role
        let userData = { userId: user.user_id, email: user.email, role: userRole };

        if (userRole === 'Student') {
            const [student] = await pool.query(
                'SELECT student_id, student_name, student_number FROM Students WHERE user_id = ?',
                [user.user_id]
            );
            if (student.length > 0) {
                userData = { ...userData, ...student[0] };
            }
        }

        res.json({
            success: true,
            message: 'Login successful',
            token,
            user: userData
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed', details: error.message });
    }
});

// ===== LOGOUT ROUTE =====

/**
 * POST /api/auth/logout
 * Logout user (client-side token removal)
 */
router.post('/logout', verifyToken, (req, res) => {
    // Token-based auth - just send success
    // Client should remove the token
    res.json({
        success: true,
        message: 'Logout successful. Please remove the token from client.'
    });
});

// ===== VERIFY TOKEN ROUTE =====

/**
 * GET /api/auth/verify
 * Verify if token is valid
 */
router.get('/verify', verifyToken, async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Get user details
        const [users] = await pool.query(
            'SELECT user_id, email FROM Users WHERE user_id = ?',
            [req.user.userId]
        );

        if (users.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({
            success: true,
            user: {
                userId: req.user.userId,
                email: req.user.email,
                role: req.user.role
            }
        });
    } catch (error) {
        console.error('Verify error:', error);
        res.status(500).json({ error: 'Verification failed' });
    }
});

module.exports = router;
