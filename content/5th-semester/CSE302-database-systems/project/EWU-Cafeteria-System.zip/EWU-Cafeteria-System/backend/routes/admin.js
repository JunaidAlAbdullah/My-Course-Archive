/**
 * Admin Routes
 * Handles admin/manager operations
 */

const express = require('express');
const { verifyToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// ===== FOOD MANAGEMENT =====

/**
 * POST /api/admin/foods
 * Create new food item
 */
router.post('/foods', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { food_name, category_id, description, price, image_url, preparation_time, quantity_available } = req.body;

        // Validation
        if (!food_name || !category_id || !price) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        // Get admin
        const [admins] = await pool.query(
            'SELECT admin_id FROM Admins WHERE user_id = ?',
            [req.user.userId]
        );

        if (admins.length === 0) {
            return res.status(404).json({ error: 'Admin not found' });
        }

        const admin_id = admins[0].admin_id;

        // Create food item
        const [result] = await pool.query(
            `INSERT INTO FoodItems (food_name, category_id, description, price, image_url, preparation_time, quantity_available, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [food_name, category_id, description || null, price, image_url || null, preparation_time || 15, quantity_available || 50, admin_id]
        );

        res.status(201).json({
            success: true,
            message: 'Food item created successfully',
            data: {
                food_id: result.insertId,
                food_name,
                price
            }
        });
    } catch (error) {
        console.error('Create food error:', error);
        res.status(500).json({ error: 'Failed to create food item' });
    }
});

/**
 * PUT /api/admin/foods/:food_id
 * Update food item
 */
router.put('/foods/:food_id', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { food_id } = req.params;
        const { food_name, description, price, image_url, availability_status, preparation_time, quantity_available } = req.body;

        const updateFields = [];
        const params = [];

        if (food_name !== undefined) {
            updateFields.push('food_name = ?');
            params.push(food_name);
        }
        if (description !== undefined) {
            updateFields.push('description = ?');
            params.push(description);
        }
        if (price !== undefined) {
            updateFields.push('price = ?');
            params.push(price);
        }
        if (image_url !== undefined) {
            updateFields.push('image_url = ?');
            params.push(image_url);
        }
        if (availability_status !== undefined) {
            updateFields.push('availability_status = ?');
            params.push(availability_status);
        }
        if (preparation_time !== undefined) {
            updateFields.push('preparation_time = ?');
            params.push(preparation_time);
        }
        if (quantity_available !== undefined) {
            updateFields.push('quantity_available = ?');
            params.push(quantity_available);
        }

        if (updateFields.length === 0) {
            return res.status(400).json({ error: 'No fields to update' });
        }

        params.push(food_id);

        await pool.query(
            `UPDATE FoodItems SET ${updateFields.join(', ')} WHERE food_id = ?`,
            params
        );

        res.json({
            success: true,
            message: 'Food item updated successfully'
        });
    } catch (error) {
        console.error('Update food error:', error);
        res.status(500).json({ error: 'Failed to update food item' });
    }
});

/**
 * DELETE /api/admin/foods/:food_id
 * Delete food item
 */
router.delete('/foods/:food_id', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { food_id } = req.params;

        // Mark as unavailable instead of deleting
        await pool.query(
            'UPDATE FoodItems SET availability_status = FALSE WHERE food_id = ?',
            [food_id]
        );

        res.json({
            success: true,
            message: 'Food item removed successfully'
        });
    } catch (error) {
        console.error('Delete food error:', error);
        res.status(500).json({ error: 'Failed to delete food item' });
    }
});

// ===== ORDER MANAGEMENT =====

/**
 * GET /api/admin/orders
 * Get all orders
 */
router.get('/orders', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { status_id, limit = 50, offset = 0 } = req.query;

        let query = `SELECT o.order_id, o.student_id, s.student_name, s.student_number,
                        o.order_date, o.order_time, ts.slot_time,
                        o.status_id, os.status_name, o.total_amount, 
                        o.payment_status, o.payment_method, o.created_at
                 FROM Orders o
                 JOIN Students s ON o.student_id = s.student_id
                 LEFT JOIN TimeSlots ts ON o.slot_id = ts.slot_id
                 JOIN OrderStatus os ON o.status_id = os.status_id`;

        const params = [];

        if (status_id) {
            query += ' WHERE o.status_id = ?';
            params.push(status_id);
        }

        query += ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const [orders] = await pool.query(query, params);

        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Get orders error:', error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
});

/**
 * PATCH /api/admin/orders/:order_id/status
 * Update order status
 */
router.patch('/orders/:order_id/status', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { order_id } = req.params;
        const { status_id } = req.body;

        if (!status_id) {
            return res.status(400).json({ error: 'Status ID required' });
        }

        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            // Update order status
            await connection.query(
                'UPDATE Orders SET status_id = ? WHERE order_id = ?',
                [status_id, order_id]
            );

            // Get order for notification
            const [orders] = await connection.query(
                'SELECT student_id FROM Orders WHERE order_id = ?',
                [order_id]
            );

            if (orders.length > 0) {
                const [students] = await connection.query(
                    'SELECT user_id FROM Students WHERE student_id = ?',
                    [orders[0].student_id]
                );

                if (students.length > 0) {
                    // Create notification
                    const [statusNames] = await connection.query(
                        'SELECT status_name FROM OrderStatus WHERE status_id = ?',
                        [status_id]
                    );

                    const statusName = statusNames.length > 0 ? statusNames[0].status_name : 'Updated';

                    await connection.query(
                        'INSERT INTO Notifications (user_id, notification_type, title, message, related_order_id) VALUES (?, ?, ?, ?, ?)',
                        [students[0].user_id, 'Order Status', `Order #${order_id} Status Updated`, `Your order status is now: ${statusName}`, order_id]
                    );
                }
            }

            await connection.commit();

            res.json({
                success: true,
                message: 'Order status updated successfully'
            });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('Update order status error:', error);
        res.status(500).json({ error: 'Failed to update order' });
    }
});

// ===== COMPLAINT MANAGEMENT =====

/**
 * GET /api/admin/complaints
 * Get all complaints
 */
router.get('/complaints', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { status, priority, limit = 50, offset = 0 } = req.query;

        let query = `SELECT c.complaint_id, c.subject, c.description, ct.type_name,
                        s.student_name, c.status, c.priority, c.created_at,
                        DATEDIFF(NOW(), c.created_at) as days_open
                 FROM Complaints c
                 JOIN ComplaintTypes ct ON c.complaint_type_id = ct.type_id
                 JOIN Students s ON c.student_id = s.student_id
                 WHERE 1=1`;

        const params = [];

        if (status) {
            query += ' AND c.status = ?';
            params.push(status);
        }

        if (priority) {
            query += ' AND c.priority = ?';
            params.push(priority);
        }

        query += ' ORDER BY c.priority DESC, c.created_at ASC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const [complaints] = await pool.query(query, params);

        res.json({
            success: true,
            data: complaints
        });
    } catch (error) {
        console.error('Get complaints error:', error);
        res.status(500).json({ error: 'Failed to fetch complaints' });
    }
});

/**
 * PATCH /api/admin/complaints/:complaint_id
 * Resolve complaint
 */
router.patch('/complaints/:complaint_id', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;
        const { complaint_id } = req.params;
        const { status, resolution_notes } = req.body;

        if (!complaint_id || isNaN(complaint_id)) {
            return res.status(400).json({ error: 'Invalid complaint ID' });
        }

        // Verify complaint exists
        const [complaintExists] = await pool.query(
            'SELECT complaint_id FROM Complaints WHERE complaint_id = ?',
            [complaint_id]
        );

        if (complaintExists.length === 0) {
            return res.status(404).json({ error: 'Complaint not found' });
        }

        // Get admin
        const [admins] = await pool.query(
            'SELECT admin_id FROM Admins WHERE user_id = ?',
            [req.user.userId]
        );

        if (admins.length === 0) {
            return res.status(404).json({ error: 'Admin not found' });
        }

        const admin_id = admins[0].admin_id;

        const updateFields = ['status = ?', 'updated_at = NOW()'];
        const params = [status || 'In Progress'];

        if (resolution_notes) {
            updateFields.push('resolution_notes = ?');
            params.push(resolution_notes);
        }

        if (status === 'Resolved' || status === 'Closed') {
            updateFields.push('resolved_by = ?', 'resolved_date = NOW()');
            params.push(admin_id);
        }

        params.push(complaint_id);

        const [result] = await pool.query(
            `UPDATE Complaints SET ${updateFields.join(', ')} WHERE complaint_id = ?`,
            params
        );

        if (result.affectedRows === 0) {
            return res.status(400).json({ error: 'Failed to update complaint' });
        }

        res.json({
            success: true,
            message: 'Complaint updated successfully'
        });
    } catch (error) {
        console.error('Update complaint error:', error);
        res.status(500).json({ error: 'Failed to update complaint: ' + error.message });
    }
});

// ===== CREATE TEST ORDER =====

/**
 * POST /api/admin/test-order
 * Create a test order for demonstration
 */
router.post('/test-order', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Get first student
        const [students] = await pool.query('SELECT student_id FROM Students LIMIT 1');
        if (students.length === 0) {
            return res.status(400).json({ error: 'No students found' });
        }

        const student_id = students[0].student_id;

        // Create order
        const [orderResult] = await pool.query(
            `INSERT INTO Orders (student_id, order_date, order_time, status_id, total_amount, payment_status, payment_method, special_instructions)
             VALUES (?, DATE(NOW()), TIME(NOW()), 1, 150.00, 'Pending', 'Cash', 'Test order')`,
            [student_id]
        );

        const order_id = orderResult.insertId;

        // Add order details
        await pool.query(
            'INSERT INTO OrderDetails (order_id, food_id, quantity, price_at_order) VALUES (?, 1, 2, 40), (?, 6, 1, 120)',
            [order_id, order_id]
        );

        res.json({
            success: true,
            message: 'Test order created',
            data: { order_id }
        });
    } catch (error) {
        console.error('Create test order error:', error);
        res.status(500).json({ error: 'Failed to create test order' });
    }
});

// ===== DASHBOARD STATISTICS =====

/**
 * GET /api/admin/dashboard
 * Get admin dashboard statistics
 */
router.get('/dashboard', verifyToken, requireRole('Admin'), async (req, res) => {
    try {
        const pool = req.app.locals.pool;

        // Today's sales
        const [todaySales] = await pool.query(
            `SELECT COUNT(*) as total_orders, SUM(total_amount) as total_revenue
       FROM Orders WHERE DATE(order_date) = DATE(NOW())`
        );

        // Pending orders
        const [pendingOrders] = await pool.query(
            'SELECT COUNT(*) as count FROM Orders WHERE status_id IN (1, 2)'
        );

        // Open complaints
        const [openComplaints] = await pool.query(
            "SELECT COUNT(*) as count FROM Complaints WHERE status IN ('Open', 'In Progress')"
        );

        // Total students
        const [totalStudents] = await pool.query(
            'SELECT COUNT(*) as count FROM Students'
        );

        // Popular foods
        const [popularFoods] = await pool.query(
            `SELECT f.food_id, f.food_name, COUNT(od.order_detail_id) as times_ordered
       FROM FoodItems f
       LEFT JOIN OrderDetails od ON f.food_id = od.food_id
       GROUP BY f.food_id, f.food_name
       ORDER BY times_ordered DESC
       LIMIT 5`
        );

        res.json({
            success: true,
            data: {
                todaySales: todaySales[0],
                pendingOrders: pendingOrders[0],
                openComplaints: openComplaints[0],
                totalStudents: totalStudents[0],
                popularFoods
            }
        });
    } catch (error) {
        console.error('Get dashboard error:', error);
        res.status(500).json({ error: 'Failed to fetch dashboard data' });
    }
});

module.exports = router;
