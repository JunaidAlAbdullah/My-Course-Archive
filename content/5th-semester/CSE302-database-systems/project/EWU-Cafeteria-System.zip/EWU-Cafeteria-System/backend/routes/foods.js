/**
 * Food/Menu Routes
 * Handles food items, categories, and ratings
 */

const express = require('express');
const { verifyToken, requireRole, optionalToken } = require('../middleware/auth');

const router = express.Router();

// ===== GET ALL CATEGORIES =====

/**
 * GET /api/foods/categories
 * Get all food categories
 */
router.get('/categories', async (req, res) => {
  try {
    const pool = req.app.locals.pool;

    const [categories] = await pool.query(
      'SELECT category_id, category_name, description, image_url FROM Categories WHERE is_active = TRUE'
    );

    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

// ===== GET ALL FOOD ITEMS =====

/**
 * GET /api/foods
 * Get all available food items with optional filtering
 * Query params: category_id, search, limit, offset
 */
router.get('/', optionalToken, async (req, res) => {
  try {
    const pool = req.app.locals.pool;
    const { category_id, search, limit = 20, offset = 0 } = req.query;

    let query = 'SELECT f.food_id, f.food_name, f.category_id, c.category_name, f.description, f.price, f.image_url, f.availability_status, f.preparation_time, f.quantity_available, f.rating, f.total_ratings FROM FoodItems f JOIN Categories c ON f.category_id = c.category_id WHERE f.availability_status = TRUE';
    const params = [];

    // Filter by category
    if (category_id) {
      query += ' AND f.category_id = ?';
      params.push(category_id);
    }

    // Search by name or description
    if (search) {
      query += ' AND (f.food_name LIKE ? OR f.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    // Order by rating
    query += ' ORDER BY f.rating DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const [foods] = await pool.query(query, params);

    // Get total count
    let countQuery = 'SELECT COUNT(*) as total FROM FoodItems f WHERE f.availability_status = TRUE';
    const countParams = [];

    if (category_id) {
      countQuery += ' AND f.category_id = ?';
      countParams.push(category_id);
    }

    if (search) {
      countQuery += ' AND (f.food_name LIKE ? OR f.description LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }

    const [countResult] = await pool.query(countQuery, countParams);
    const total = countResult[0].total;

    res.json({
      success: true,
      data: foods,
      pagination: {
        total,
        limit: parseInt(limit),
        offset: parseInt(offset),
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get foods error:', error);
    res.status(500).json({ error: 'Failed to fetch food items' });
  }
});

// ===== GET SINGLE FOOD ITEM =====

/**
 * GET /api/foods/:food_id
 * Get single food item details with ratings
 */
router.get('/:food_id', optionalToken, async (req, res) => {
  try {
    const pool = req.app.locals.pool;
    const { food_id } = req.params;

    // Get food item
    const [foods] = await pool.query(
      `SELECT f.food_id, f.food_name, f.category_id, c.category_name, 
              f.description, f.price, f.image_url, f.availability_status, 
              f.preparation_time, f.quantity_available, f.rating, f.total_ratings
       FROM FoodItems f 
       JOIN Categories c ON f.category_id = c.category_id 
       WHERE f.food_id = ?`,
      [food_id]
    );

    if (foods.length === 0) {
      return res.status(404).json({ error: 'Food item not found' });
    }

    const food = foods[0];

    // Get ratings and reviews
    const [ratings] = await pool.query(
      `SELECT fr.rating_id, fr.rating_score, fr.review_text, 
              s.student_name, fr.created_at
       FROM FoodRatings fr
       JOIN Students s ON fr.student_id = s.student_id
       WHERE fr.food_id = ?
       ORDER BY fr.created_at DESC
       LIMIT 10`,
      [food_id]
    );

    res.json({
      success: true,
      data: {
        ...food,
        ratings
      }
    });
  } catch (error) {
    console.error('Get food item error:', error);
    res.status(500).json({ error: 'Failed to fetch food item' });
  }
});

// ===== RATE FOOD ITEM =====

/**
 * POST /api/foods/:food_id/rate
 * Student rates a food item
 */
router.post('/:food_id/rate', verifyToken, requireRole('Student'), async (req, res) => {
  try {
    const pool = req.app.locals.pool;
    const { food_id } = req.params;
    const { rating_score, review_text } = req.body;

    // Validation
    if (!rating_score || rating_score < 1 || rating_score > 5) {
      return res.status(400).json({ error: 'Rating must be between 1 and 5' });
    }

    // Get student
    const [students] = await pool.query(
      'SELECT student_id FROM Students WHERE user_id = ?',
      [req.user.userId]
    );

    if (students.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const student_id = students[0].student_id;

    const connection = await pool.getConnection();

    try {
      await connection.beginTransaction();

      // Check if already rated
      const [existing] = await connection.query(
        'SELECT rating_id FROM FoodRatings WHERE food_id = ? AND student_id = ?',
        [food_id, student_id]
      );

      let ratingId;

      if (existing.length > 0) {
        // Update existing rating
        ratingId = existing[0].rating_id;
        await connection.query(
          'UPDATE FoodRatings SET rating_score = ?, review_text = ? WHERE rating_id = ?',
          [rating_score, review_text || null, ratingId]
        );
      } else {
        // Insert new rating
        const [result] = await connection.query(
          'INSERT INTO FoodRatings (food_id, student_id, rating_score, review_text) VALUES (?, ?, ?, ?)',
          [food_id, student_id, rating_score, review_text || null]
        );
        ratingId = result.insertId;
      }

      // Update average rating and total_ratings in FoodItems
      const [ratingStats] = await connection.query(
        'SELECT AVG(rating_score) as avg_rating, COUNT(*) as total FROM FoodRatings WHERE food_id = ?',
        [food_id]
      );

      await connection.query(
        'UPDATE FoodItems SET rating = ?, total_ratings = ? WHERE food_id = ?',
        [ratingStats[0].avg_rating || 0, ratingStats[0].total || 0, food_id]
      );

      await connection.commit();

      res.status(201).json({
        success: true,
        message: 'Rating submitted successfully',
        data: { ratingId, rating_score, review_text }
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    console.error('Rate food error:', error);
    res.status(500).json({ error: 'Failed to submit rating' });
  }
});

// ===== GET POPULAR FOODS =====

/**
 * GET /api/foods/popular/list
 * Get top rated and most ordered food items
 */
router.get('/popular/list', async (req, res) => {
  try {
    const pool = req.app.locals.pool;
    const limit = req.query.limit || 10;

    const [foods] = await pool.query(
      `SELECT f.food_id, f.food_name, f.category_id, c.category_name, 
              f.price, f.image_url, f.rating, 
              COUNT(od.order_detail_id) as times_ordered
       FROM FoodItems f
       LEFT JOIN Categories c ON f.category_id = c.category_id
       LEFT JOIN OrderDetails od ON f.food_id = od.food_id
       WHERE f.availability_status = TRUE
       GROUP BY f.food_id, f.food_name, f.category_id, c.category_name, f.price, f.image_url, f.rating
       ORDER BY f.rating DESC, times_ordered DESC
       LIMIT ?`,
      [parseInt(limit)]
    );

    res.json({
      success: true,
      data: foods
    });
  } catch (error) {
    console.error('Get popular foods error:', error);
    res.status(500).json({ error: 'Failed to fetch popular foods' });
  }
});

module.exports = router;
