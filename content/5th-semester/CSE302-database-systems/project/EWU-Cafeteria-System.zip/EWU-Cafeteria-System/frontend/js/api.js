/**
 * API Service
 * Handles all HTTP requests to the backend
 */

const API_BASE_URL = 'http://localhost:3000/api';

class APIService {
    constructor() {
        this.token = localStorage.getItem('token');
    }

    /**
     * Generic fetch function
     */
    async request(endpoint, method = 'GET', data = null) {
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json',
            }
        };

        // Add authorization token if available
        if (this.token) {
            options.headers['Authorization'] = `Bearer ${this.token}`;
        }

        // Add request body for POST, PUT, PATCH
        if (data && ['POST', 'PUT', 'PATCH'].includes(method)) {
            options.body = JSON.stringify(data);
        }

        const fullUrl = `${API_BASE_URL}${endpoint}`;
        console.log(`[API DEBUG] ${method} ${fullUrl}`, data || '');

        try {
            const response = await fetch(fullUrl, options);

            console.log(`[API DEBUG] Response Status: ${response.status}`);

            if (!response.ok) {
                let error;
                try {
                    error = await response.json();
                } catch (parseError) {
                    error = { error: response.statusText };
                }
                console.error(`[API ERROR] ${response.status}:`, error);
                throw new Error(error.error || error.message || `HTTP ${response.status}`);
            }

            const jsonResponse = await response.json();
            console.log(`[API DEBUG] Response Success:`, jsonResponse);
            return jsonResponse;
        } catch (error) {
            console.error('[API CRITICAL ERROR]:', error.message);
            console.error('[API CRITICAL ERROR] Stack:', error.stack);
            throw error;
        }
    }

    /**
     * Test connection to backend
     */
    async testConnection() {
        try {
            console.log('[CONNECTION TEST] Testing backend connection...');
            const response = await fetch(`${API_BASE_URL.replace('/api', '')}/`);
            const data = await response.json();
            console.log('[CONNECTION TEST] SUCCESS:', data);
            return true;
        } catch (error) {
            console.error('[CONNECTION TEST] FAILED:', error.message);
            return false;
        }
    }

    /**
     * SET TOKEN
     */
    setToken(token) {
        this.token = token;
        localStorage.setItem('token', token);
    }

    /**
     * REMOVE TOKEN
     */
    removeToken() {
        this.token = null;
        localStorage.removeItem('token');
    }

    // ===== AUTHENTICATION =====

    async register(email, password, phone, student_name, student_number, department) {
        const response = await this.request('/auth/register', 'POST', {
            email, password, phone, student_name, student_number, department
        });
        this.setToken(response.token);
        return response;
    }

    async login(email, password) {
        const response = await this.request('/auth/login', 'POST', {
            email, password
        });
        this.setToken(response.token);
        return response;
    }

    async logout() {
        return this.request('/auth/logout', 'POST');
    }

    async verifyToken() {
        return this.request('/auth/verify', 'GET');
    }

    // ===== FOODS =====

    async getCategories() {
        return this.request('/foods/categories', 'GET');
    }

    async getFoods(categoryId = null, search = null, limit = 20, offset = 0) {
        let endpoint = '/foods?limit=' + limit + '&offset=' + offset;
        if (categoryId) endpoint += '&category_id=' + categoryId;
        if (search) endpoint += '&search=' + encodeURIComponent(search);
        return this.request(endpoint, 'GET');
    }

    async getFood(foodId) {
        return this.request(`/foods/${foodId}`, 'GET');
    }

    async rateFood(foodId, rating_score, review_text) {
        return this.request(`/foods/${foodId}/rate`, 'POST', {
            rating_score, review_text
        });
    }

    async getPopularFoods(limit = 10) {
        return this.request(`/foods/popular/list?limit=${limit}`, 'GET');
    }

    // ===== ORDERS =====

    async placeOrder(items, payment_method, special_instructions) {
        return this.request('/orders', 'POST', {
            items, payment_method, special_instructions
        });
    }

    async getMyOrders() {
        return this.request('/orders/my-orders', 'GET');
    }

    async getOrder(orderId) {
        return this.request(`/orders/${orderId}`, 'GET');
    }

    async cancelOrder(orderId) {
        return this.request(`/orders/${orderId}/cancel`, 'PATCH');
    }

    // ===== STUDENTS =====

    async getStudentProfile() {
        return this.request('/students/profile', 'GET');
    }

    async updateStudentProfile(data) {
        return this.request('/students/profile', 'PUT', data);
    }

    async submitComplaint(complaint_type_id, subject, description, order_id, attachment_url) {
        return this.request('/students/complaints', 'POST', {
            complaint_type_id, subject, description, order_id, attachment_url
        });
    }

    async getComplaints() {
        return this.request('/students/complaints', 'GET');
    }

    async submitFeedback(subject, message, rating, order_id) {
        return this.request('/students/feedback', 'POST', {
            subject, message, rating, order_id
        });
    }

    async getStudentStats() {
        return this.request('/students/stats', 'GET');
    }

    // ===== ADMIN =====

    async createFood(data) {
        return this.request('/admin/foods', 'POST', data);
    }

    async updateFood(foodId, data) {
        return this.request(`/admin/foods/${foodId}`, 'PUT', data);
    }

    async deleteFood(foodId) {
        return this.request(`/admin/foods/${foodId}`, 'DELETE');
    }

    async getAdminOrders(statusId = null, limit = 50, offset = 0) {
        let endpoint = `/admin/orders?limit=${limit}&offset=${offset}`;
        if (statusId) endpoint += `&status_id=${statusId}`;
        return this.request(endpoint, 'GET');
    }

    async updateOrderStatus(orderId, statusId) {
        return this.request(`/admin/orders/${orderId}/status`, 'PATCH', {
            status_id: statusId
        });
    }

    async getAdminComplaints(status = null, priority = null) {
        let endpoint = '/admin/complaints';
        if (status || priority) {
            endpoint += '?';
            if (status) endpoint += `status=${status}`;
            if (priority) endpoint += (status ? '&' : '') + `priority=${priority}`;
        }
        return this.request(endpoint, 'GET');
    }

    async updateComplaint(complaintId, status, resolution_notes) {
        return this.request(`/admin/complaints/${complaintId}`, 'PATCH', {
            status, resolution_notes
        });
    }

    async getAdminDashboard() {
        return this.request('/admin/dashboard', 'GET');
    }

    // ===== STAFF =====

    async getStaffOrders(statusId = null) {
        let endpoint = '/staff/orders';
        if (statusId) endpoint += `?status_id=${statusId}`;
        const token = this.token;
        console.log('[API] getStaffOrders - Token exists:', !!token, 'Token:', token ? token.substring(0, 20) + '...' : null);
        return this.request(endpoint, 'GET');
    }

    async updateStaffOrderStatus(orderId, statusId) {
        return this.request(`/staff/orders/${orderId}/status`, 'PATCH', {
            status_id: statusId
        });
    }

    async getStaffDashboard() {
        return this.request('/staff/dashboard', 'GET');
    }

    async createTestOrder() {
        return this.request('/staff/test-order', 'POST');
    }

    async createAdminTestOrder() {
        return this.request('/admin/test-order', 'POST');
    }

    // ===== NOTIFICATIONS =====

    async getNotifications(limit = 20, offset = 0) {
        return this.request(`/notifications?limit=${limit}&offset=${offset}`, 'GET');
    }

    async markNotificationAsRead(notificationId) {
        return this.request(`/notifications/${notificationId}/read`, 'PATCH');
    }

    async markAllNotificationsAsRead() {
        return this.request('/notifications/read-all', 'PATCH');
    }

    async deleteNotification(notificationId) {
        return this.request(`/notifications/${notificationId}`, 'DELETE');
    }

    async getUnreadNotificationCount() {
        return this.request('/notifications/count/unread', 'GET');
    }

    // ===== COMPLAINT METHODS =====

    async getComplaintTypes() {
        return this.request('/complaints/types', 'GET');
    }

    async getComplaints() {
        return this.request('/complaints', 'GET');
    }

    async getComplaint(complaintId) {
        return this.request(`/complaints/${complaintId}`, 'GET');
    }

    async createComplaint(complaintData) {
        return this.request('/complaints', 'POST', complaintData);
    }

    async updateStudentComplaint(complaintId, complaintData) {
        return this.request(`/complaints/${complaintId}`, 'PUT', complaintData);
    }
}

// Create global instance
const api = new APIService();
