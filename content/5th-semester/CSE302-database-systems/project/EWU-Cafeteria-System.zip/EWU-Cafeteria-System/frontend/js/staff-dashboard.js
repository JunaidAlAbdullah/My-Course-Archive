/**
 * Staff Dashboard JavaScript
 */

requireAuth();

let currentOrderId = null;
let currentOrderStatus = null;
let currentFilter = 'all';

document.addEventListener('DOMContentLoaded', async () => {
    // Check authorization
    const user = getCurrentUser();
    if (user?.role !== 'Staff') {
        window.location.href = '/pages/login.html';
    }

    // Load initial data
    await loadStaffDashboard();
    await loadOrders();

    // Refresh data every 10 seconds
    setInterval(() => {
        loadOrders();
        loadStaffDashboard();
        updateCurrentTime();
    }, 10000);

    // Update time every second
    updateCurrentTime();
    setInterval(updateCurrentTime, 1000);
});

// ===== VIEW SWITCHING =====

function switchStaffView(view) {
    $$('.view').forEach(v => hide(v));
  $$('.compact-nav-btn').forEach(btn => btn.classList.remove('is-active'));

    show($(`#${view}-view`));

  const activeButton = document.querySelector(`.compact-nav-btn[onclick*="switchStaffView('${view}')"]`);
  if (activeButton) {
    activeButton.classList.add('is-active');
  }

    if (view === 'orders') {
        loadOrders();
    }
}

// ===== TIME UPDATE =====

function updateCurrentTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    $('#current-time').textContent = `${hours}:${minutes}`;
}

// ===== DASHBOARD =====

async function loadStaffDashboard() {
    try {
        const response = await api.getStaffDashboard();
        const data = response.data;

        $('#stat-preparing').textContent = data.preparing.count || 0;
        $('#stat-ready').textContent = data.ready.count || 0;
        $('#stat-pending').textContent = data.pending.count || 0;

        // Display recent orders
        let recentHTML = '';
        const recent = data.recentOrders.slice(0, 5);
        recent.forEach(order => {
            const statusColor = {
                'Pending': '#FFA500',
                'Confirmed': '#1E90FF',
                'Preparing': '#FFD700',
                'Ready': '#32CD32'
            }[order.status_name] || '#666';

            recentHTML += `
        <div style="padding: 0.75rem; margin-bottom: 0.5rem; background-color: var(--bg-secondary); border-left: 4px solid ${statusColor}; border-radius: 4px;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
            <strong>Order #${order.order_id}</strong>
            <span style="background-color: ${statusColor}; color: white; padding: 0.25rem 0.5rem; border-radius: 3px; font-size: 0.75rem;">
              ${order.status_name}
            </span>
          </div>
          <p style="margin: 0; font-size: 0.875rem; color: var(--text-secondary);">${order.student_name}</p>
        </div>
      `;
        });
        $('#recent-orders').innerHTML = recentHTML;

        // Quick stats
        let statsHTML = `
      <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--bg-secondary);">
        <strong>Confirmed Pending:</strong> ${data.pending.count} items
      </li>
      <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--bg-secondary);">
        <strong>In Preparation:</strong> ${data.preparing.count} items
      </li>
      <li style="padding: 0.5rem 0;">
        <strong>Ready for Pickup:</strong> ${data.ready.count} items
      </li>
    `;
        $('#quick-stats').innerHTML = statsHTML;
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// ===== ORDERS =====

async function loadOrders() {
    try {
        const orderDiv = document.getElementById('orders-list');
        orderDiv.innerHTML = '<div class="text-center p-4"><div class="spinner"></div><p class="mt-2">Loading orders...</p></div>';
        
        const response = await api.getStaffOrders();
        const orders = response.data;

        // Count by status
        const pendingOrders = orders.filter(o => o.status_id === 1 || o.status_id === 2);
        const preparingOrders = orders.filter(o => o.status_id === 3);
        const readyOrders = orders.filter(o => o.status_id === 4);

        $('#count-pending').textContent = pendingOrders.length;
        $('#count-preparing').textContent = preparingOrders.length;
        $('#count-ready').textContent = readyOrders.length;

        displayOrders(orders);
    } catch (error) {
        console.error('[Staff] Load orders error:', error);
        const orderDiv = document.getElementById('orders-list');
        orderDiv.innerHTML = `<div class="alert alert-danger">Error loading orders: ${error.message}. Make sure backend is running.</div>`;
    }
}

function displayOrders(orders) {
    const ordersDiv = $('#orders-list');

    if (orders.length === 0) {
      ordersDiv.innerHTML = '<div class="card compact-empty"><p class="text-center text-muted">No orders to prepare</p></div>';
        return;
    }

    let filteredOrders = orders;

    if (currentFilter === 'pending') {
        filteredOrders = orders.filter(o => o.status_id === 2);
    } else if (currentFilter === 'preparing') {
        filteredOrders = orders.filter(o => o.status_id === 3);
    } else if (currentFilter === 'ready') {
        filteredOrders = orders.filter(o => o.status_id === 4);
    }

    if (filteredOrders.length === 0) {
      ordersDiv.innerHTML = '<div class="card compact-empty"><p class="text-center text-muted">No orders in this category</p></div>';
        return;
    }

    let html = '<div class="orders-grid">';

    filteredOrders.forEach(order => {
        const statusColor = {
            'Pending': '#FFA500',
            'Confirmed': '#1E90FF',
            'Preparing': '#FFD700',
            'Ready': '#32CD32'
        }[order.status_name] || '#666';

        html += `
      <div class="order-card" style="border-left-color: ${statusColor};">
        <div class="order-card-header">
          <div style="flex: 1;">
            <h4 class="order-card-title">Order #${order.order_id}</h4>
            <p class="order-card-student">${order.student_name}</p>
            <p class="order-card-time">⏰ ${order.order_time}</p>
          </div>
          <span class="order-card-status" style="background-color: ${statusColor};">
            ${order.status_name}
          </span>
        </div>

        ${order.special_instructions ? `<p class="order-card-special">📝 ${order.special_instructions}</p>` : ''}

        <div class="order-card-items">
          <strong>Items:</strong>
          <ul>
            ${order.items.map(item => `<li><strong>${item.food_name}</strong> x${item.quantity}${item.special_notes ? ` (${item.special_notes})` : ''}</li>`).join('')}
          </ul>
        </div>

        <div class="order-card-actions">
          ${order.status_id === 1 || order.status_id === 2 ? `
            <button class="btn btn-primary" onclick="openOrderAction(${order.order_id}, 3, 'Preparing')">Start</button>
          ` : ''}
          ${order.status_id === 3 ? `
            <button class="btn btn-success" onclick="openOrderAction(${order.order_id}, 4, 'Ready')">Ready</button>
            <button class="btn btn-secondary" onclick="openOrderAction(${order.order_id}, 2, 'Confirm')">Back</button>
          ` : ''}
          ${order.status_id === 4 ? `
            <button class="btn btn-success" onclick="openOrderAction(${order.order_id}, 5, 'Picked Up')">Picked Up</button>
          ` : ''}
        </div>
      </div>
    `;
    });

    html += '</div>';
    ordersDiv.innerHTML = html;
}

function filterOrders(filter) {
    currentFilter = filter;
    loadOrders();
    switchStaffView('orders');
}

// ===== ORDER ACTIONS =====

function openOrderAction(orderId, statusId, statusName) {
    currentOrderId = orderId;
    currentOrderStatus = statusId;

    const actionText = {
        3: '🔥 Start Preparing',
        4: '✅ Mark as Ready',
        5: '📦 Mark as Picked Up',
        2: '↩️ Move Back to Pending'
    }[statusId] || 'Update Status';

    const readyNotification = statusId === 4 ? 'This will notify the student that their order is ready' : '';

    $('#order-action-content').innerHTML = `
    <p><strong>Order #${orderId}</strong></p>
    <p>Change status to: <strong>${statusName}</strong></p>
    ${readyNotification ? `<p style="color: var(--warning-color);"><strong>⚠️ ${readyNotification}</strong></p>` : ''}
  `;

    openModal('orderActionModal');
}

async function confirmOrderAction() {
    try {
        await api.updateStaffOrderStatus(currentOrderId, currentOrderStatus);
        showSuccess('Order status updated');
        closeModal('orderActionModal');
        await loadOrders();
        await loadStaffDashboard();
    } catch (error) {
        showError(error.message || 'Failed to update order');
    }
}

async function createTestOrder() {
    try {
        await api.createTestOrder();
        showSuccess('Test order created!');
        await loadOrders();
        await loadStaffDashboard();
    } catch (error) {
        showError('Failed to create test order: ' + error.message);
    }
}
