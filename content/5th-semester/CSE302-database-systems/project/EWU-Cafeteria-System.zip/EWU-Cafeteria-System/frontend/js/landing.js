/**
 * Landing Page JavaScript
 * Loads popular food items and handles interactions
 */

document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Load popular foods
        const response = await api.getPopularFoods(12);
        displayPopularFoods(response.data);
    } catch (error) {
        console.error('Error loading popular foods:', error);
    }
});

function displayPopularFoods(foods) {
    const popularFoodsDiv = $('#popular-foods');
    if (!popularFoodsDiv) return;

    if (foods.length === 0) {
        popularFoodsDiv.innerHTML = '<p class="text-center">No popular items available at the moment.</p>';
        return;
    }

    popularFoodsDiv.innerHTML = foods.map(food => `
    <div class="food-card">
      <img src="${food.image_url || '/images/placeholder.jpg'}" alt="${food.food_name}" class="food-card-image">
      <div class="food-card-content">
        <span class="food-card-category">${food.category_name}</span>
        <h4 class="food-card-name">${food.food_name}</h4>
        <p class="food-card-description">${food.description || 'Delicious food item'}</p>
      </div>
      <div class="food-card-footer">
        <div class="food-card-price">${formatPrice(food.price)}</div>
        <div class="food-card-rating">
          ${renderStars(food.rating)}
          <span>(${food.total_ratings || 0})</span>
        </div>
      </div>
    </div>
  `).join('');
}
