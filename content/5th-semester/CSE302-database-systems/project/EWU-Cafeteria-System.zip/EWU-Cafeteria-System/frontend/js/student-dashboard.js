/**
 * Student Dashboard JavaScript
 */

requireAuth();

let currentFoodId = null;

document.addEventListener('DOMContentLoaded', async () => {
    // Set user name
    const user = getCurrentUser();
    $('#user-name').textContent = user?.student_name || 'Student';
    
    // Set welcome banner
    $('#welcome-name').textContent = user?.student_name || 'Student';
    const timeOfDay = getGreetingTime();
    const messages = [
        `Ready to order some delicious food?`,
        `Fresh food awaits you today!`,
        `Treat yourself with something tasty!`,
        `Your favorite meals are here!`
    ];
    const randomMessage = messages[Math.floor(Math.random() * messages.length)];
    $('#welcome-message').textContent = randomMessage;

    // Load initial data
    await loadCategories();
    await loadFoods();
    await loadOrders();
    await loadNotifications();
    
    // Update stats
    updateWelcomeStats();
});

// Helper function to get greeting based on time
function getGreetingTime() {
    const hour = new Date().getHours();
    if (hour < 12) return 'Morning';
    if (hour < 18) return 'Afternoon';
    return 'Evening';
}

// Update welcome banner stats
async function updateWelcomeStats() {
    try {
        const response = await api.getMyOrders();
        const ordersCount = response.data?.length || 0;
        $('#stats-orders').textContent = ordersCount;
    } catch (error) {
        console.error('Error updating welcome stats:', error);
    }
}

// ===== VIEW SWITCHING =====

function switchView(view) {
    // Hide all views
    $$('.view').forEach(v => hide(v));

    // Show selected view
    show($(`#${view}-view`));

    // Reload data for specific views
    if (view === 'orders') {
        loadOrders();
    } else if (view === 'notifications') {
        loadNotifications();
    } else if (view === 'cart') {
        loadCartFoodData().then(() => updateCartDisplay());
    }
}

// ===== CATEGORIES =====

async function loadCategories() {
    try {
        const response = await api.getCategories();
        const categoriesDiv = $('#categories');

        let html = '<button class="btn btn-secondary" onclick="filterByCategory(null)">All</button>';

        response.data.forEach(category => {
            html += `<button class="btn btn-secondary" onclick="filterByCategory(${category.category_id})">${category.category_name}</button>`;
        });

        categoriesDiv.innerHTML = html;
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

let currentCategoryId = null;

async function filterByCategory(categoryId) {
    currentCategoryId = categoryId;
    await loadFoods();
}

// ===== FOODS =====

async function loadFoods() {
    try {
        const response = await api.getFoods(currentCategoryId);
        displayFoods(response.data);
    } catch (error) {
        showError('Failed to load foods');
        console.error(error);
    }
}

function displayFoods(foods) {
    const foodsDiv = $('#foods');

    if (foods.length === 0) {
        foodsDiv.innerHTML = '<p class="text-center">No foods available</p>';
        return;
    }

    foodsDiv.innerHTML = foods.map(food => `
    <div class="food-card" onclick="openFoodModal(${food.food_id})">
      <img src="${food.image_url || '/images/placeholder.jpg'}" alt="${food.food_name}" class="food-card-image">
      <div class="food-card-content">
        <span class="food-card-category">${food.category_name}</span>
        <h4 class="food-card-name">${food.food_name}</h4>
        <p class="food-card-description">${(food.description || 'Delicious food').substring(0, 60)}...</p>
      </div>
      <div class="food-card-footer">
        <div class="food-card-price">${formatPrice(food.price)}</div>
        <div class="food-card-rating">
          ${renderStars(food.rating)}
          <span>(${food.total_ratings || 0})</span>
        </div>
        <div class="food-card-stock" style="margin-top: 0.5rem; font-size: 0.85rem; color: ${food.quantity_available > 0 ? 'var(--text-secondary)' : '#dc3545'};">
          ${food.quantity_available > 0 ? `Stock: ${food.quantity_available}` : 'Out of Stock'}
        </div>
      </div>
    </div>
  `).join('');
}

// ===== FOOD MODAL =====

async function openFoodModal(foodId) {
    try {
        const response = await api.getFood(foodId);
        const food = response.data;

        currentFoodId = food.food_id;

        $('#modal-title').textContent = food.food_name;
        $('#modal-image').src = food.image_url || '/images/placeholder.jpg';
        $('#modal-category').textContent = food.category_name;
        $('#modal-price').textContent = formatPrice(food.price);
        $('#modal-description').textContent = food.description;
        
        // Display stock status
        const stockDiv = $('#modal-stock');
        if (food.quantity_available > 0) {
            stockDiv.textContent = `✓ In Stock: ${food.quantity_available} available`;
            stockDiv.style.color = 'var(--text-secondary)';
        } else {
            stockDiv.textContent = '✗ Out of Stock';
            stockDiv.style.color = '#dc3545';
        }
        
        $('#modal-quantity').value = 1;
        $('#modal-quantity').max = food.quantity_available || 1;

        // Display ratings
        let ratingsHTML = '<div class="mb-2">';
        ratingsHTML += `<div class="food-card-rating">${renderStars(food.rating)} (${food.total_ratings} ratings)</div>`;
        if (food.ratings && food.ratings.length > 0) {
            ratingsHTML += '<div style="margin-top: 1rem; border-top: 1px solid var(--bg-secondary); padding-top: 1rem;">';
            food.ratings.slice(0, 3).forEach(rating => {
                ratingsHTML += `
          <div style="margin-bottom: 0.75rem;">
            <div style="display: flex; justify-content: space-between;">
              <strong>${rating.student_name}</strong>
              <span>${renderStars(rating.rating_score)}</span>
            </div>
            <p style="margin: 0.25rem 0; color: var(--text-secondary); font-size: 0.875rem;">${rating.review_text}</p>
          </div>
        `;
            });
            ratingsHTML += '</div>';
        }
        ratingsHTML += '</div>';

        $('#modal-ratings').innerHTML = ratingsHTML;

        openModal('foodModal');
    } catch (error) {
        showError('Failed to load food details');
        console.error(error);
    }
}

function increaseQuantity() {
    const input = $('#modal-quantity');
    input.value = parseInt(input.value) + 1;
}

function decreaseQuantity() {
    const input = $('#modal-quantity');
    if (parseInt(input.value) > 1) {
        input.value = parseInt(input.value) - 1;
    }
}

function addToCartFromModal() {
    const quantity = parseInt($('#modal-quantity').value);
    addToCart(currentFoodId, quantity);
    closeModal('foodModal');
    updateCartBadge();
}

// ===== SEARCH =====

const searchDebounce = debounce(async (searchTerm) => {
    try {
        if (!searchTerm) {
            await loadFoods();
        } else {
            const response = await api.getFoods(currentCategoryId, searchTerm);
            displayFoods(response.data);
        }
    } catch (error) {
        console.error('Search error:', error);
    }
}, 300);

$('#search-input').addEventListener('input', (e) => {
    searchDebounce(e.target.value);
});

// ===== CART =====

function updateCartDisplay() {
    const cart = getCart();
    const cartItemsDiv = $('#cart-items');

    if (cart.length === 0) {
        cartItemsDiv.innerHTML = '<div class="card compact-empty"><p class="text-center text-muted">Your cart is empty</p></div>';
        $('#cart-subtotal').textContent = '৳0';
        $('#cart-total').textContent = '৳0';
        return;
    }

    let totalAmount = 0;
    let html = '';

    cart.forEach(item => {
        if (!item.foodData) return; // Load full data if not available

        const itemTotal = item.price * item.quantity;
        totalAmount += itemTotal;

        html += `
            <div class="card cart-item-card">
                <div class="cart-item-head">
                    <div class="cart-item-main">
                        <h4 class="cart-item-title">${item.foodName}</h4>
                        <p class="cart-item-meta">${formatPrice(item.price)} x ${item.quantity}</p>
                        <p class="cart-item-total">${formatPrice(itemTotal)}</p>
          </div>
          <button class="btn btn-danger btn-sm" onclick="removeFromCart(${item.food_id}); updateCartDisplay();">Remove</button>
        </div>
                <div class="cart-item-controls">
          <button class="btn btn-secondary btn-sm" onclick="updateCartQuantity(${item.food_id}, ${item.quantity - 1}); updateCartDisplay();">-</button>
          <input type="number" class="form-control" value="${item.quantity}" style="flex: 1; text-align: center;" readonly>
          <button class="btn btn-secondary btn-sm" onclick="updateCartQuantity(${item.food_id}, ${item.quantity + 1}); updateCartDisplay();">+</button>
        </div>
      </div>
    `;
    });

    cartItemsDiv.innerHTML = html;
    $('#cart-subtotal').textContent = formatPrice(totalAmount);
    $('#cart-total').textContent = formatPrice(totalAmount);
}

// Need to load food data for cart items
async function loadCartFoodData() {
    const cart = getCart();
    for (let item of cart) {
        try {
            const response = await api.getFood(item.food_id);
            item.foodData = response.data;
            item.foodName = response.data.food_name;
            item.price = response.data.price;
        } catch (error) {
            console.error('Error loading food data:', error);
        }
    }
    setLocalStorage('cart', cart);
}

// ===== CHECKOUT =====

async function checkout() {
    const cart = getCart();
    const paymentMethod = $('#payment-select').value;
    const instructions = $('#instructions').value;

    if (cart.length === 0) {
        showError('Your cart is empty');
        return;
    }

    try {
        await loadCartFoodData();

        // Validate stock availability before checkout
        for (let item of cart) {
            if (!item.foodData || item.foodData.quantity_available < item.quantity) {
                showError(`Insufficient stock for ${item.foodName}. Only ${item.foodData?.quantity_available || 0} available.`);
                return;
            }
        }

        const items = cart.map(item => ({
            food_id: item.food_id,
            quantity: item.quantity
        }));

        const response = await api.placeOrder(
            items,
            paymentMethod,
            instructions || null
        );

        showSuccess('Order placed successfully!');
        clearCart();
        updateCartDisplay();
        $('#instructions').value = '';

        setTimeout(() => {
            switchView('orders');
            loadOrders();
        }, 1500);
    } catch (error) {
        showError(error.message || 'Failed to place order');
    }
}

// ===== ORDERS =====

async function loadOrders() {
    try {
        const response = await api.getMyOrders();
        displayOrders(response.data);
    } catch (error) {
        showError('Failed to load orders');
        console.error(error);
    }
}

function displayOrders(orders) {
    const ordersDiv = $('#orders-list');

    if (orders.length === 0) {
        ordersDiv.innerHTML = '<div class="card compact-empty"><p class="text-center text-muted">You have no orders yet</p></div>';
        return;
    }

    let html = '';

    orders.forEach(order => {
        const statusClass = getStatusBadgeClass(order.status_name);

        html += `
            <div class="card order-history-card">
                <div class="order-history-head">
                    <div class="order-history-main">
                        <div class="order-history-title-row">
                            <h4 class="order-history-title">Order #${order.order_id}</h4>
              <span class="badge-status ${statusClass}">${order.status_name}</span>
            </div>
                        <p class="order-history-meta">
              📅 ${formatDate(order.order_date)} | ⏰ ${order.order_time}
            </p>
                        <p class="order-history-meta">
              Payment: ${order.payment_method} | Status: <strong>${order.payment_status}</strong>
            </p>
          </div>
                    <div class="order-history-side">
                        <p class="order-history-total">${formatPrice(order.total_amount)}</p>
            <button class="btn btn-secondary btn-sm" onclick="loadOrderDetails(${order.order_id})">View Details</button>
            ${order.status_id <= 2 ? `<button class="btn btn-danger btn-sm" style="margin-top: 0.5rem;" onclick="cancelOrder(${order.order_id})">Cancel</button>` : ''}
          </div>
        </div>
                <div class="order-history-items">
          <strong>Items:</strong>
                    <ul>
            ${order.items.map(item => `<li>${item.food_name} x ${item.quantity}</li>`).join('')}
          </ul>
        </div>
      </div>
    `;
    });

    ordersDiv.innerHTML = html;
}

async function loadOrderDetails(orderId) {
    try {
        const response = await api.getOrder(orderId);
        // Could open a modal with detailed information
        showSuccess('Order details loaded');
        console.log('Order details:', response.data);
    } catch (error) {
        showError('Failed to load order details');
    }
}

async function cancelOrder(orderId) {
    if (confirm('Are you sure you want to cancel this order?')) {
        try {
            await api.cancelOrder(orderId);
            showSuccess('Order cancelled successfully');
            await loadOrders();
        } catch (error) {
            showError(error.message || 'Failed to cancel order');
        }
    }
}

// ===== NOTIFICATIONS =====

async function loadNotifications() {
    try {
        const response = await api.getNotifications(50);
        displayNotifications(response.data);

        // Update badge
        const unreadCount = response.unreadCount;
        const badge = $('#notification-badge');
        if (unreadCount > 0) {
            show(badge);
            badge.textContent = unreadCount;
        } else {
            hide(badge);
        }
    } catch (error) {
        console.error('Error loading notifications:', error);
    }
}

function displayNotifications(notifications) {
    const notificationsDiv = $('#notifications-list');

    if (notifications.length === 0) {
        notificationsDiv.innerHTML = '<div class="card compact-empty"><p class="text-center text-muted">No notifications</p></div>';
        return;
    }

    let html = '';

    notifications.forEach(notif => {
        const isRead = notif.is_read ? ' opacity: 0.6;' : '';

        html += `
            <div class="card notification-card" style="${isRead}">
                <div class="notification-head">
                    <div class="notification-main">
                        <h4 class="notification-title">${notif.title}</h4>
                        <p class="notification-message">${notif.message}</p>
                        <p class="notification-time">${formatDateTime(notif.created_at)}</p>
          </div>
          <button class="btn btn-danger btn-sm" onclick="deleteNotification(${notif.notification_id})">Delete</button>
        </div>
      </div>
    `;
    });

    notificationsDiv.innerHTML = html;
}

async function deleteNotification(notificationId) {
    try {
        await api.deleteNotification(notificationId);
        await loadNotifications();
    } catch (error) {
        showError('Failed to delete notification');
    }
}

// ===== COMPLAINTS =====

async function openComplaintsModal() {
    openModal('complaintsModal');
    await loadComplaints();
}

async function loadComplaints() {
    try {
        const response = await api.getComplaints();
        displayComplaints(response.data);
    } catch (error) {
        showError('Failed to load complaints');
        console.error(error);
    }
}

function displayComplaints(complaints) {
    const complaintsList = $('#complaints-list');

    if (complaints.length === 0) {
        complaintsList.innerHTML = '<p class="text-center text-secondary">No complaints filed yet</p>';
        return;
    }

    complaintsList.innerHTML = complaints.map(comp => `
        <div class="card mb-2">
            <div class="card-body">
                <div class="flex flex-between mb-1">
                    <h4 class="card-title">${comp.subject}</h4>
                    <span class="badge badge-${comp.status.toLowerCase() === 'open' ? 'warning' : 'success'}">${comp.status}</span>
                </div>
                <p class="text-secondary text-sm mb-1">${comp.type_name}</p>
                <p class="text-sm mb-1">${comp.description}</p>
                <small class="text-secondary">${new Date(comp.created_at).toLocaleDateString()}</small>
            </div>
        </div>
    `).join('');
}

function openFileComplaintModal() {
    closeModal('complaintsModal');
    openModal('fileComplaintModal');
    loadComplaintForm();
}

async function loadComplaintForm() {
    try {
        // Load complaint types
        const typesResponse = await api.getComplaintTypes();
        const typeSelect = $('#complaint-type');
        typeSelect.innerHTML = '<option value="">Select complaint type</option>';
        typesResponse.data.forEach(type => {
            const option = document.createElement('option');
            option.value = type.type_id;
            option.textContent = type.type_name;
            typeSelect.appendChild(option);
        });

        // Load user orders
        const ordersResponse = await api.getMyOrders();
        const orderSelect = $('#complaint-order');
        orderSelect.innerHTML = '<option value="">Select an order (optional)</option>';
        ordersResponse.data.forEach(order => {
            const option = document.createElement('option');
            option.value = order.order_id;
            option.textContent = `Order #${order.order_id} - ${order.created_at.split('T')[0]}`;
            orderSelect.appendChild(option);
        });
    } catch (error) {
        showError('Failed to load complaint form');
        console.error(error);
    }
}

async function submitComplaint() {
    try {
        const complaintData = {
            complaint_type_id: parseInt($('#complaint-type').value),
            subject: $('#complaint-subject').value,
            description: $('#complaint-description').value,
            order_id: $('#complaint-order').value ? parseInt($('#complaint-order').value) : null
        };

        if (!complaintData.complaint_type_id || !complaintData.subject || !complaintData.description) {
            showError('Please fill in all required fields');
            return;
        }

        await api.createComplaint(complaintData);
        showSuccess('Complaint filed successfully');
        closeModal('fileComplaintModal');

        // Reset form
        $('#complaint-type').value = '';
        $('#complaint-subject').value = '';
        $('#complaint-description').value = '';
        $('#complaint-order').value = '';

        // Reopen complaints list
        openComplaintsModal();
    } catch (error) {
        showError('Failed to submit complaint: ' + error.message);
        console.error(error);
    }
}
