/**
 * Admin Dashboard JavaScript
 */

requireAuth();

let currentOrderId = null;
let currentComplaintId = null;
let editingFoodId = null;

document.addEventListener('DOMContentLoaded', async () => {
    await loadAdminDashboard();
    await loadCategories();
});

// ===== VIEW SWITCHING =====

async function switchAdminView(view) {
    $$('.view').forEach(v => hide(v));
    $$('.compact-nav-btn').forEach(btn => btn.classList.remove('is-active'));

    show($(`#${view}-view`));

    const activeButton = document.querySelector(`.compact-nav-btn[onclick*="switchAdminView('${view}')"]`);
    if (activeButton) {
        activeButton.classList.add('is-active');
    }

    if (view === 'foods') {
        await loadFoods();
    } else if (view === 'orders') {
        await loadAdminOrders();
    } else if (view === 'complaints') {
        await loadComplaints();
    }
}

// ===== DASHBOARD STATISTICS =====

async function loadAdminDashboard() {
    try {
        const response = await api.getAdminDashboard();
        const data = response.data;

        $('#stat-today-orders').textContent = data.todaySales.total_orders || 0;
        $('#stat-today-revenue').textContent = formatPrice(data.todaySales.total_revenue || 0);
        $('#stat-pending-orders').textContent = data.pendingOrders.count || 0;
        $('#stat-open-complaints').textContent = data.openComplaints.count || 0;
        $('#stat-total-students').textContent = data.totalStudents.count || 0;

        // Display popular foods
        let foodsHTML = '';
        data.popularFoods.forEach(food => {
            foodsHTML += `
        <li style="padding: 0.5rem 0; display: flex; justify-content: space-between;">
          <span>${food.food_name}</span>
          <strong style="color: var(--primary-color);">${food.times_ordered} orders</strong>
        </li>
      `;
        });
        $('#popular-foods-list').innerHTML = foodsHTML;
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// ===== CATEGORIES =====

async function loadCategories() {
    try {
        const response = await api.getCategories();
        const select = $('#food-category-select');

        select.innerHTML = '<option value="">Select Category</option>';

        response.data.forEach(category => {
            select.innerHTML += `<option value="${category.category_id}">${category.category_name}</option>`;
        });
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// ===== FOOD MANAGEMENT =====

async function loadFoods() {
    try {
        const response = await api.getFoods(null, null, 100);
        displayFoodsList(response.data);
    } catch (error) {
        showError('Failed to load foods');
    }
}

function displayFoodsList(foods) {
    const foodsDiv = $('#foods-list');

    if (foods.length === 0) {
        foodsDiv.innerHTML = '<div class="card compact-empty"><p class="empty-title">No foods available</p></div>';
        return;
    }

    foodsDiv.innerHTML = foods.map(food => `
        <div class="food-card">
            <img src="${food.image_url || '/images/placeholder.jpg'}" alt="${food.food_name}" class="food-card-image">

            <div class="food-card-content">
                <span class="food-card-category">${food.category_name}</span>
                <h4 class="food-card-name">${food.food_name}</h4>
                <p class="food-card-description">${food.description || 'No description'}</p>
            </div>

            <div class="food-card-footer">
                <div class="compact-meta-stack">
                    <p><strong>Price:</strong> ${formatPrice(food.price)}</p>
                    <p><strong>Stock:</strong> ${food.quantity_available}</p>
                </div>
        <div>
                    <span class="badge-status" style="background-color: ${food.availability_status ? '#D4EDDA' : '#F8D7DA'}; color: ${food.availability_status ? '#155724' : '#721C24'};">
            ${food.availability_status ? 'Available' : 'Unavailable'}
          </span>
        </div>
      </div>

            <div class="food-card-content" style="padding-top: 0;">
                <div class="order-card-actions">
        <button class="btn btn-secondary btn-sm" onclick="editFood(${food.food_id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteFood(${food.food_id})">Delete</button>
                </div>
      </div>
    </div>
  `).join('');
}

function openAddFoodModal() {
    editingFoodId = null;
    $('#food-modal-title').textContent = 'Add Food Item';
    $('#foodForm').reset();
    openModal('foodModal');
}

function editFood(foodId) {
    editingFoodId = foodId;
    // In a real app, would load food data and populate form
    $('#food-modal-title').textContent = 'Edit Food Item';
    openModal('foodModal');
}

async function handleFoodSubmit(e) {
    e.preventDefault();

    const formData = new FormData($('#foodForm'));
    const data = Object.fromEntries(formData);

    try {
        if (editingFoodId) {
            await api.updateFood(editingFoodId, data);
            showSuccess('Food item updated successfully');
        } else {
            await api.createFood(data);
            showSuccess('Food item created successfully');
        }

        closeModal('foodModal');
        await loadFoods();
    } catch (error) {
        showError(error.message || 'Failed to save food');
    }
}

async function deleteFood(foodId) {
    if (confirm('Are you sure you want to delete this food item?')) {
        try {
            await api.deleteFood(foodId);
            showSuccess('Food item deleted');
            await loadFoods();
        } catch (error) {
            showError('Failed to delete food');
        }
    }
}

// ===== ORDER MANAGEMENT =====

async function loadAdminOrders() {
    try {
        const statusId = $('#order-status-filter').value;
        console.log('[Admin] Loading orders with status:', statusId);
        const response = await api.getAdminOrders(statusId || null);
        console.log('[Admin] Orders loaded:', response.data.length, 'orders');
        displayOrdersList(response.data);
    } catch (error) {
        console.error('[Admin] Load orders error:', error);
        showError('Failed to load orders');
    }
}

function displayOrdersList(orders) {
    const ordersDiv = $('#orders-list');

    if (orders.length === 0) {
        ordersDiv.innerHTML = '<div class="card compact-empty"><p class="text-muted">No orders found</p></div>';
        return;
    }

    let html = '<div class="orders-grid">';

    orders.forEach(order => {
        const statusColor = {
            'Pending': '#FFA500',
            'Confirmed': '#1E90FF',
            'Preparing': '#FFD700',
            'Ready': '#32CD32',
            'Picked Up': '#228B22',
            'Cancelled': '#DC143C',
            'Refunded': '#A9A9A9'
        }[order.status_name] || '#666';

        html += `
      <div class="order-card" style="border-left-color: ${statusColor};">
        <div class="order-card-header">
          <div style="flex: 1;">
            <h4 class="order-card-title">Order #${order.order_id}</h4>
            <p class="order-card-student">${order.student_name}</p>
            <p class="order-card-time" style="font-size: 0.75rem;">ID: ${order.student_number}</p>
            <p class="order-card-time">⏰ ${order.order_time}</p>
          </div>
          <span class="order-card-status" style="background-color: ${statusColor};">
            ${order.status_name}
          </span>
        </div>

        <div style="font-size: 0.85rem; margin-bottom: 0.75rem;">
          <p style="margin: 0.25rem 0; color: var(--text-secondary);"><strong>Amount:</strong> ${formatPrice(order.total_amount)}</p>
          <p style="margin: 0.25rem 0; color: var(--text-secondary);"><strong>Payment:</strong> ${order.payment_method}</p>
          <p style="margin: 0.25rem 0; color: var(--text-secondary);"><strong>Status:</strong> ${order.payment_status}</p>
        </div>

        <div class="order-card-actions">
          <button class="btn btn-primary" onclick="openUpdateOrderStatus(${order.order_id}, '${order.status_name}')">Update</button>
        </div>
      </div>
    `;
    });

    html += '</div>';
    ordersDiv.innerHTML = html;
}

function openUpdateOrderStatus(orderId, currentStatus) {
    currentOrderId = orderId;
    $('#order-status-text').textContent = `Current Status: ${currentStatus}`;
    openModal('orderStatusModal');
}

async function updateOrderStatus() {
    const statusId = $('#new-status-select').value;

    if (!statusId) {
        showError('Please select a new status');
        return;
    }

    try {
        await api.updateOrderStatus(currentOrderId, parseInt(statusId));
        showSuccess('Order status updated');
        closeModal('orderStatusModal');
        await loadAdminOrders();
    } catch (error) {
        showError('Failed to update order');
    }
}

// ===== COMPLAINT MANAGEMENT =====

async function loadComplaints() {
    try {
        const status = $('#complaint-status-filter').value;
        const priority = $('#complaint-priority-filter').value;
        const response = await api.getAdminComplaints(status || null, priority || null);
        displayComplaintsList(response.data);
    } catch (error) {
        showError('Failed to load complaints');
    }
}

// Store complaints for detail access
let complaintsMap = {};

function displayComplaintsList(complaints) {
    const complaintsDiv = $('#complaints-list');

    if (complaints.length === 0) {
        complaintsDiv.innerHTML = '<div class="card compact-empty"><p class="text-muted">No complaints found</p></div>';
        return;
    }

    // Store complaints in map for detail access
    complaintsMap = {};
    complaints.forEach(c => {
        complaintsMap[c.complaint_id] = c;
    });

    let html = '<div class="orders-grid">';

    complaints.forEach(complaint => {
        const priorityColor = {
            'High': '#DC143C',
            'Medium': '#FFA500',
            'Low': '#32CD32'
        }[complaint.priority] || '#666';

        const statusBgColor = {
            'Resolved': '#D4EDDA',
            'In Progress': '#FFE5B4',
            'Open': '#FFF3CD',
            'Closed': '#D1E7DD'
        }[complaint.status] || '#F0F0F0';

        html += `
      <div class="order-card" style="border-left-color: ${priorityColor};">
        <div class="order-card-header">
          <div style="flex: 1;">
            <h4 class="order-card-title" style="font-size: 0.9rem;">${(complaint.subject || 'N/A').substring(0, 30)}</h4>
            <p class="order-card-student">${complaint.student_name || 'Unknown'}</p>
            <p class="order-card-time" style="font-size: 0.75rem;">${complaint.type_name || 'N/A'}</p>
          </div>
          <div style="display: flex; flex-direction: column; gap: 0.25rem;">
            <span class="order-card-status" style="background-color: ${statusBgColor}; color: var(--text-primary); font-size: 0.65rem;">
              ${complaint.status || 'Unknown'}
            </span>
            <span class="order-card-status" style="background-color: ${priorityColor}; font-size: 0.65rem;">
              ${complaint.priority || 'Medium'}
            </span>
          </div>
        </div>

        <p style="font-size: 0.75rem; color: var(--text-secondary); margin: 0.5rem 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
          ${(complaint.description || 'No description').substring(0, 100)}
        </p>

        <p style="font-size: 0.75rem; color: var(--text-muted); margin: 0.25rem 0;">Days Open: <strong>${complaint.days_open || 0}</strong></p>

        <div class="order-card-actions">
          <button class="btn btn-primary" onclick="openResolveComplaint(${complaint.complaint_id})">Handle</button>
        </div>
      </div>
    `;
    });

    html += '</div>';
    complaintsDiv.innerHTML = html;
}

async function openResolveComplaint(complaintId) {
    if (!complaintId || !complaintsMap[complaintId]) {
        showError('Complaint not found');
        return;
    }

    const complaint = complaintsMap[complaintId];
    currentComplaintId = complaint.complaint_id;

    $('#complaint-status-select').value = complaint.status || 'Open';
    $('#complaint-notes').value = '';

    const detailsDiv = $('#complaint-details');
    detailsDiv.innerHTML = `
        <div class="mb-2" style="background: var(--bg-secondary); padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
            <p><strong>Subject:</strong> ${complaint.subject || 'N/A'}</p>
            <p><strong>Type:</strong> ${complaint.type_name || 'N/A'}</p>
            <p><strong>Student:</strong> ${complaint.student_name || 'Unknown'}</p>
            <p><strong>Days Open:</strong> ${complaint.days_open || 0}</p>
            <p><strong>Description:</strong></p>
            <p style="padding: 0.5rem; background: var(--bg-tertiary); border-radius: var(--radius); margin-top: 0.5rem;">${complaint.description || 'No description provided'}</p>
        </div>
    `;

    console.log('Opening complaint:', complaint);
    openModal('complaintModal');
}

async function resolveComplaint() {
    const status = $('#complaint-status-select').value;
    const notes = $('#complaint-notes').value;

    if (!status) {
        showError('Please select a status');
        return;
    }

    if (!currentComplaintId) {
        showError('Complaint ID not found');
        return;
    }

    try {
        console.log('Updating complaint:', {
            complaintId: currentComplaintId,
            status: status,
            resolution_notes: notes
        });

        await api.updateComplaint(currentComplaintId, status, notes);
        showSuccess('Complaint updated successfully');
        closeModal('complaintModal');
        await loadComplaints();
    } catch (error) {
        console.error('Complaint update error:', error);
        showError('Failed to update complaint: ' + (error.message || error));
    }
}

// ===== INITIALIZATION =====

// Check authorization
const user = getCurrentUser();
if (user?.role !== 'Admin') {
    window.location.href = '/pages/login.html';
}
