/**
 * Utility Functions
 * Helper functions for common operations
 */

// ===== DOM UTILITIES =====

function $(selector) {
    return document.querySelector(selector);
}

function $$(selector) {
    return document.querySelectorAll(selector);
}

function show(element) {
    if (element) element.classList.remove('hidden');
}

function hide(element) {
    if (element) element.classList.add('hidden');
}

function toggle(element) {
    if (element) element.classList.toggle('hidden');
}

// ===== SESSION MANAGEMENT =====

function getCurrentUser() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

function setCurrentUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/pages/login.html';
}

function isAuthenticated() {
    return !!localStorage.getItem('token');
}

function requireAuth() {
    if (!isAuthenticated()) {
        window.location.href = '/pages/login.html';
    }
}

// ===== FORMATTING =====

function formatPrice(price) {
    return '৳' + parseFloat(price).toFixed(2);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-BD', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-BD') + ' ' + date.toLocaleTimeString('en-BD');
}

function formatTime(timeString) {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
}

// ===== VALIDATION =====

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\d\+\-\(\)\s]{10,}$/;
    return re.test(phone);
}

function validatePassword(password) {
    return password.length >= 6;
}

// ===== TOAST NOTIFICATIONS =====

let toastContainer = null;

function getToastContainer() {
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        toastContainer.id = 'toast-container';
        document.body.appendChild(toastContainer);
    }
    return toastContainer;
}

function showToast(message, type = 'info', duration = 4000) {
    const container = getToastContainer();
    
    const icons = {
        success: '✓',
        error: '✕',
        info: 'ℹ',
        warning: '⚠'
    };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${icons[type] || icons.info}</span>
        <span class="toast-content">${message}</span>
        <button class="toast-close" onclick="dismissToast(this.parentElement)">&times;</button>
        <div class="toast-progress"></div>
    `;

    container.appendChild(toast);

    if (duration > 0) {
        setTimeout(() => {
            dismissToast(toast);
        }, duration);
    }

    return toast;
}

function dismissToast(toast) {
    if (!toast || !toast.parentElement) return;
    toast.classList.add('toast-exit');
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 300);
}

function showAlert(message, type = 'info') {
    showToast(message, type);
}

function showSuccess(message) {
    showToast(message, 'success');
}

function showError(message) {
    showToast(message, 'error');
}

function showInfo(message) {
    showToast(message, 'info');
}

function showWarning(message) {
    showToast(message, 'warning');
}

// ===== MODAL FUNCTIONS =====

function openModal(modalId) {
    const modal = $(`#${modalId}`);
    if (modal) {
        modal.classList.add('active');
    }
}

function closeModal(modalId) {
    const modal = $(`#${modalId}`);
    if (modal) {
        modal.classList.remove('active');
    }
}

function closeAllModals() {
    $$('.modal').forEach(modal => {
        modal.classList.remove('active');
    });
}

// Close modal when clicking outside
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});

// ===== LOADING STATE =====

function showLoading(element) {
    if (element) {
        element.innerHTML = '<div class="spinner"></div>';
        element.style.pointerEvents = 'none';
        element.style.opacity = '0.6';
    }
}

function hideLoading(element) {
    if (element) {
        element.style.pointerEvents = 'auto';
        element.style.opacity = '1';
    }
}

// ===== FORM UTILITIES =====

function getFormData(formId) {
    const form = $(`#${formId}`);
    if (!form) return null;

    const formData = new FormData(form);
    const data = {};

    formData.forEach((value, key) => {
        data[key] = value;
    });

    return data;
}

function resetForm(formId) {
    const form = $(`#${formId}`);
    if (form) form.reset();
}

function disableForm(formId) {
    const form = $(`#${formId}`);
    if (form) {
        $$(`#${formId} input, #${formId} select, #${formId} textarea, #${formId} button`).forEach(el => {
            el.disabled = true;
        });
    }
}

function enableForm(formId) {
    const form = $(`#${formId}`);
    if (form) {
        $$(`#${formId} input, #${formId} select, #${formId} textarea, #${formId} button`).forEach(el => {
            el.disabled = false;
        });
    }
}

// ===== LOCAL STORAGE =====

function getLocalStorage(key) {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
}

function setLocalStorage(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

function removeLocalStorage(key) {
    localStorage.removeItem(key);
}

// ===== CART MANAGEMENT =====

function getCart() {
    return getLocalStorage('cart') || [];
}

function addToCart(foodId, quantity = 1) {
    const cart = getCart();
    const item = cart.find(i => i.food_id === foodId);

    if (item) {
        item.quantity += quantity;
    } else {
        cart.push({ food_id: foodId, quantity });
    }

    setLocalStorage('cart', cart);
    showSuccess('Added to cart');
    updateCartBadge();
}

function removeFromCart(foodId) {
    let cart = getCart();
    cart = cart.filter(i => i.food_id !== foodId);
    setLocalStorage('cart', cart);
    updateCartBadge();
}

function updateCartQuantity(foodId, quantity) {
    const cart = getCart();
    const item = cart.find(i => i.food_id === foodId);
    if (item) {
        item.quantity = Math.max(1, quantity);
    }
    setLocalStorage('cart', cart);
}

function clearCart() {
    removeLocalStorage('cart');
    updateCartBadge();
}

function getCartTotal() {
    const cart = getCart();
    return cart.reduce((total, item) => total + (item.quantity * (item.price || 0)), 0);
}

function updateCartBadge() {
    const cart = getCart();
    const badge = $('#cart-badge');
    if (badge) {
        badge.textContent = cart.length;
        if (cart.length === 0) {
            hide(badge);
        } else {
            show(badge);
        }
    }
}

// ===== DEBOUNCE & THROTTLE =====

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function (...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// ===== STAR RATING =====

function renderStars(rating, maxRating = 5) {
    let stars = '';
    for (let i = 1; i <= maxRating; i++) {
        if (i <= Math.round(rating)) {
            stars += '<span class="star">★</span>';
        } else {
            stars += '<span class="star" style="opacity: 0.3;">★</span>';
        }
    }
    return stars;
}

// ===== BADGE STYLING =====

function getStatusBadgeClass(status) {
    const statusMap = {
        'Pending': 'badge-pending',
        'Confirmed': 'badge-confirmed',
        'Preparing': 'badge-preparing',
        'Ready': 'badge-ready',
        'Picked Up': 'badge-ready',
        'Cancelled': 'badge-cancelled'
    };
    return statusMap[status] || 'badge-pending';
}

// ===== SCROLL TO ELEMENT =====

function scrollToElement(selector) {
    const element = $(selector);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

// ===== INIT CART BADGE =====

document.addEventListener('DOMContentLoaded', () => {
    updateCartBadge();
});
