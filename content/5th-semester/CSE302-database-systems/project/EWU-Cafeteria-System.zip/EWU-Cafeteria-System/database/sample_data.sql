-- Sample Data for EWU Cafeteria Pre-Order System

USE ewu_cafeteria_project;

-- ===== SAMPLE USERS ONLY (Passwords: student=password, admin=admin123, staff=staff123) =====

INSERT IGNORE INTO Users (email, password_hash, phone) VALUES
('student1@ewu.edu', '$2a$10$66qlshD7/PxpZpTX7F5WKemNHe/10Q6.0Qkx91L3ZDMcxySKZOauu', '01712345678'),
('student2@ewu.edu', '$2a$10$66qlshD7/PxpZpTX7F5WKemNHe/10Q6.0Qkx91L3ZDMcxySKZOauu', '01712345679'),
('admin@cafeteria.ewu.edu', '$2a$10$9BEUgvBJ8je98hyvuBHjHewWo.LIVe2ErM7ZzWQ3C9rElEChWl3nC', '01900000001'),
('staff1@cafeteria.ewu.edu', '$2a$10$mL/bPtBc.XMEvLQpyLX8aekBlxhJFrJOqSiv9pe9Mt85SSZTRbu7W', '01900000101'),
('authority@ewu.edu', '$2a$10$66qlshD7/PxpZpTX7F5WKemNHe/10Q6.0Qkx91L3ZDMcxySKZOauu', '01900000200');

INSERT IGNORE INTO User_Roles (user_id, role_id)
SELECT u.user_id, r.role_id
FROM Users u
JOIN Roles r ON r.role_name = 'Student'
WHERE u.email IN ('student1@ewu.edu', 'student2@ewu.edu')
UNION ALL
SELECT u.user_id, r.role_id
FROM Users u
JOIN Roles r ON r.role_name = 'Admin'
WHERE u.email = 'admin@cafeteria.ewu.edu'
UNION ALL
SELECT u.user_id, r.role_id
FROM Users u
JOIN Roles r ON r.role_name = 'Staff'
WHERE u.email = 'staff1@cafeteria.ewu.edu'
UNION ALL
SELECT u.user_id, r.role_id
FROM Users u
JOIN Roles r ON r.role_name = 'Authority'
WHERE u.email = 'authority@ewu.edu';

-- ===== SEED STUDENT PROFILES =====
INSERT IGNORE INTO Students (user_id, student_name, student_number, department, semester, total_orders, loyalty_points)
SELECT u.user_id, 'Student One', 'STU-001', 'CSE', 8, 0, 0
FROM Users u
WHERE u.email = 'student1@ewu.edu';

INSERT IGNORE INTO Students (user_id, student_name, student_number, department, semester, total_orders, loyalty_points)
SELECT u.user_id, 'Student Two', 'STU-002', 'BBA', 6, 0, 0
FROM Users u
WHERE u.email = 'student2@ewu.edu';

INSERT IGNORE INTO Admins (user_id, admin_name, position, salary, hire_date)
SELECT u.user_id, 'Main Admin', 'Cafeteria Manager', 0.00, CURDATE()
FROM Users u
WHERE u.email = 'admin@cafeteria.ewu.edu';

-- ===== SEED STAFF PROFILES =====
INSERT IGNORE INTO Staff (user_id, staff_name, position, salary, shift, hire_date, assigned_admin_id, is_available)
SELECT u.user_id, 'Staff One', 'Kitchen Staff', 0.00, 'Morning', CURDATE(), a.admin_id, TRUE
FROM Users u
LEFT JOIN Admins a ON a.user_id = (SELECT user_id FROM Users WHERE email = 'admin@cafeteria.ewu.edu' LIMIT 1)
WHERE u.email = 'staff1@cafeteria.ewu.edu';

-- ===== SEED CATEGORIES =====
INSERT IGNORE INTO Categories (category_id, category_name, description) VALUES
(1, 'Breakfast', ' Morning meals'),
(2, 'Lunch', ' Afternoon meals'),
(3, 'Dinner', ' Evening meals'),
(4, 'Snacks', ' Quick bites'),
(5, 'Beverages', ' Drinks');

-- ===== SEED TIME SLOTS =====
INSERT IGNORE INTO TimeSlots (slot_id, slot_time, available_capacity, current_orders, is_active) VALUES
(1, '08:00:00', 20, 0, TRUE),
(2, '09:00:00', 25, 0, TRUE),
(3, '10:00:00', 25, 0, TRUE),
(4, '11:00:00', 30, 0, TRUE),
(5, '12:00:00', 30, 0, TRUE),
(6, '13:00:00', 30, 0, TRUE),
(7, '14:00:00', 25, 0, TRUE),
(8, '15:00:00', 25, 0, TRUE),
(9, '16:00:00', 20, 0, TRUE),
(10, '17:00:00', 20, 0, TRUE);

-- ===== SEED FOOD ITEMS =====
INSERT IGNORE INTO FoodItems (food_id, category_id, food_name, description, price, image_url, preparation_time, quantity_available, availability_status, created_by) VALUES
(1, 1, 'Plain Paratha', 'Crispy flatbread served with curry', 40.00, NULL, 15, 50, TRUE, 1),
(2, 1, 'Pori Polao', 'Fried rice with peas and potatoes', 50.00, NULL, 20, 40, TRUE, 1),
(3, 1, 'Chai & Biscuit', 'Tea with biscuits', 20.00, NULL, 5, 100, TRUE, 1),
(4, 1, 'Egg Bhuna', 'Spicy scrambled eggs', 45.00, NULL, 10, 30, TRUE, 1),
(5, 1, 'Pitha & Chanar Curti', 'Rice cake with cottage cheese', 35.00, NULL, 15, 25, TRUE, 1),
(6, 2, 'Chicken Biryani', 'Aromatic rice with chicken', 120.00, NULL, 25, 35, TRUE, 1),
(7, 2, 'Beef Biryani', 'Aromatic rice with beef', 110.00, NULL, 25, 30, TRUE, 1),
(8, 2, 'Chicken Curry with Rice', 'Chicken curry with steamed rice', 90.00, NULL, 20, 40, TRUE, 1),
(9, 2, 'Vegetable Curry with Rice', 'Mixed vegetable curry with rice', 60.00, NULL, 15, 45, TRUE, 1),
(10, 2, 'Fish Curry with Rice', 'Fish curry with steamed rice', 80.00, NULL, 20, 30, TRUE, 1),
(11, 2, 'Dal with Rice', 'Lentils with steamed rice', 40.00, NULL, 10, 60, TRUE, 1),
(12, 2, 'Chicken Fried Rice', 'Stir-fried rice with chicken', 80.00, NULL, 15, 35, TRUE, 1),
(13, 3, 'Chicken Biryani', 'Aromatic rice with chicken', 120.00, NULL, 25, 35, TRUE, 1),
(14, 3, 'Beef Biryani', 'Aromatic rice with beef', 110.00, NULL, 25, 30, TRUE, 1),
(15, 3, 'Kacchi Biryani', 'Half cooked rice with meat', 130.00, NULL, 30, 25, TRUE, 1),
(16, 3, 'Polao', 'Simple fried rice', 60.00, NULL, 15, 40, TRUE, 1),
(17, 3, 'Chicken Curry', 'Traditional chicken curry', 100.00, NULL, 20, 30, TRUE, 1),
(18, 3, 'Vegetable Khichuri', 'Mixed vegetable khichdi', 55.00, NULL, 15, 35, TRUE, 1),
(19, 4, 'Samosa', 'Crispy pastry with potatoes', 15.00, NULL, 5, 80, TRUE, 1),
(20, 4, 'Pakora', 'Spicy vegetable fritters', 10.00, NULL, 5, 100, TRUE, 1),
(21, 4, 'Chicken Roll', 'Flatbread with chicken', 50.00, NULL, 10, 50, TRUE, 1),
(22, 4, 'Egg Roll', 'Flatbread with egg', 35.00, NULL, 8, 60, TRUE, 1),
(23, 4, 'Fries', 'Crispy potato fries', 30.00, NULL, 8, 70, TRUE, 1),
(24, 4, 'Chat', 'Mixed spicy snack', 40.00, NULL, 5, 50, TRUE, 1),
(25, 5, 'Water Bottle', 'Drinking water', 10.00, NULL, 1, 200, TRUE, 1),
(26, 5, 'Chai/Tea', 'Sweet tea', 15.00, NULL, 3, 150, TRUE, 1),
(27, 5, 'Cold Coffee', 'Iced coffee', 50.00, NULL, 5, 60, TRUE, 1),
(28, 5, 'Soft Drinks', 'Coca Cola/Pepsi', 20.00, NULL, 1, 100, TRUE, 1),
(29, 5, 'Lassi', 'Sweet yogurt drink', 30.00, NULL, 3, 80, TRUE, 1),
(30, 5, 'Juice', 'Mixed fruit juice', 40.00, NULL, 3, 70, TRUE, 1);