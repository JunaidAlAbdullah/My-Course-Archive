-- EWU Cafeteria Pre-Order System Database Schema
-- Normalized to 3NF with proper indexes and constraints
-- ============================================
-- SAMPLE USER PASSWORDS (bcrypt hashed in database):
-- Students: password (e.g., student1@ewu.edu)
-- Admin: admin123 (e.g., admin@cafeteria.ewu.edu)
-- Staff: staff123 (e.g., staff1@cafeteria.ewu.edu)
-- ============================================

-- Create Database
CREATE DATABASE IF NOT EXISTS ewu_cafeteria_project;
USE ewu_cafeteria_project;

-- ===== USERS AND ROLES TABLES =====

-- Users Table (Base table for all user types)
CREATE TABLE Users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
);

-- User Roles Reference Table
CREATE TABLE Roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO Roles (role_name, description) VALUES
('Student', 'Student user who can pre-order food'),
('Admin', 'Cafeteria manager with full control'),
('Staff', 'Kitchen staff member'),
('Authority', 'EWU Authority for monitoring');

-- User Role Junction Table (Supports multiple roles per user)
CREATE TABLE User_Roles (
    user_role_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    role_id INT NOT NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (role_id) REFERENCES Roles(role_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_role (user_id, role_id),
    INDEX idx_user_id (user_id),
    INDEX idx_role_id (role_id)
);

-- Students Table
CREATE TABLE Students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    student_name VARCHAR(100) NOT NULL,
    student_number VARCHAR(20) UNIQUE NOT NULL,
    department VARCHAR(100),
    semester INT,
    profile_picture_url VARCHAR(255),
    total_orders INT DEFAULT 0,
    loyalty_points INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    INDEX idx_student_number (student_number),
    INDEX idx_user_id (user_id)
);

-- Admin/Manager Table
CREATE TABLE Admins (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    admin_name VARCHAR(100) NOT NULL,
    position VARCHAR(100),
    salary DECIMAL(10, 2),
    hire_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
);

-- Staff Table
CREATE TABLE Staff (
    staff_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    staff_name VARCHAR(100) NOT NULL,
    position VARCHAR(100),
    salary DECIMAL(10, 2),
    shift VARCHAR(50), -- Morning, Evening, Night
    hire_date DATE,
    assigned_admin_id INT,
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_admin_id) REFERENCES Admins(admin_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_assigned_admin_id (assigned_admin_id)
);

-- ===== FOOD AND MENU TABLES =====

-- Food Categories Table
CREATE TABLE Categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    image_url VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO Categories (category_name, description, image_url, is_active) VALUES
('Breakfast', 'Morning meals and beverages', '/images/breakfast.jpg', TRUE),
('Lunch', 'Main course meals', '/images/lunch.jpg', TRUE),
('Dinner', 'Evening meals', '/images/dinner.jpg', TRUE),
('Snacks', 'Light snacks and desserts', '/images/snacks.jpg', TRUE),
('Beverages', 'Hot and cold drinks', '/images/beverages.jpg', TRUE);

-- Food Items Table
CREATE TABLE FoodItems (
    food_id INT PRIMARY KEY AUTO_INCREMENT,
    food_name VARCHAR(100) NOT NULL,
    category_id INT NOT NULL,
    description TEXT,
    price DECIMAL(8, 2) NOT NULL,
    image_url VARCHAR(255),
    availability_status BOOLEAN DEFAULT TRUE,
    preparation_time INT DEFAULT 15, -- in minutes
    quantity_available INT DEFAULT 50,
    rating DECIMAL(3, 2) DEFAULT 0,
    total_ratings INT DEFAULT 0,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES Categories(category_id) ON DELETE RESTRICT,
    FOREIGN KEY (created_by) REFERENCES Admins(admin_id) ON DELETE SET NULL,
    INDEX idx_category_id (category_id),
    INDEX idx_availability_status (availability_status),
    INDEX idx_rating (rating)
);

-- Food Ratings/Reviews Table
CREATE TABLE FoodRatings (
    rating_id INT PRIMARY KEY AUTO_INCREMENT,
    food_id INT NOT NULL,
    student_id INT NOT NULL,
    rating_score INT NOT NULL CHECK (rating_score >= 1 AND rating_score <= 5),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (food_id) REFERENCES FoodItems(food_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    UNIQUE KEY unique_food_student_rating (food_id, student_id),
    INDEX idx_food_id (food_id),
    INDEX idx_student_id (student_id)
);

-- ===== ORDER RELATED TABLES =====

-- Time Slots Table
CREATE TABLE TimeSlots (
    slot_id INT PRIMARY KEY AUTO_INCREMENT,
    slot_time VARCHAR(50) NOT NULL UNIQUE, -- e.g., "12:00 PM - 1:00 PM"
    available_capacity INT DEFAULT 50,
    current_orders INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO TimeSlots (slot_time, available_capacity, is_active) VALUES
('8:00 AM - 9:00 AM', 50, TRUE),
('9:00 AM - 10:00 AM', 50, TRUE),
('12:00 PM - 1:00 PM', 60, TRUE),
('1:00 PM - 2:00 PM', 60, TRUE),
('4:00 PM - 5:00 PM', 40, TRUE),
('5:00 PM - 6:00 PM', 40, TRUE);

-- Order Status Reference Table
CREATE TABLE OrderStatus (
    status_id INT PRIMARY KEY AUTO_INCREMENT,
    status_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    color_code VARCHAR(20)
);

INSERT INTO OrderStatus (status_name, description, color_code) VALUES
('Pending', 'Order placed, awaiting confirmation', '#FFA500'),
('Confirmed', 'Order confirmed by admin', '#1E90FF'),
('Preparing', 'Kitchen is preparing the order', '#FFD700'),
('Ready', 'Order ready for pickup', '#32CD32'),
('Picked Up', 'Order picked up by student', '#228B22'),
('Cancelled', 'Order cancelled', '#DC143C'),
('Refunded', 'Payment refunded to student', '#A9A9A9');

-- Orders Table
CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    order_date DATE NOT NULL,
    order_time TIME NOT NULL,
    slot_id INT NULL,
    status_id INT NOT NULL DEFAULT 1,
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_status VARCHAR(50) DEFAULT 'Pending',
    payment_method VARCHAR(50),
    special_instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES TimeSlots(slot_id) ON DELETE SET NULL,
    FOREIGN KEY (status_id) REFERENCES OrderStatus(status_id) ON DELETE RESTRICT,
    INDEX idx_student_id (student_id),
    INDEX idx_order_date (order_date),
    INDEX idx_status_id (status_id),
    INDEX idx_slot_id (slot_id)
);

-- Order Details Table (Each item in an order)
CREATE TABLE OrderDetails (
    order_detail_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    price_at_order DECIMAL(8, 2) NOT NULL,
    special_notes TEXT,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (food_id) REFERENCES FoodItems(food_id) ON DELETE RESTRICT,
    INDEX idx_order_id (order_id),
    INDEX idx_food_id (food_id)
);

-- ===== PAYMENT AND FINANCE TABLES =====

-- Payments Table (For staff salaries and EWU rent)
CREATE TABLE Payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    payment_type VARCHAR(50) NOT NULL, -- Staff Salary, EWU Rent, Other
    recipient_type VARCHAR(50), -- Staff, EWU Authority
    recipient_id INT,
    amount DECIMAL(12, 2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method VARCHAR(50),
    reference_number VARCHAR(100),
    processed_by INT, -- Admin who approved
    status VARCHAR(50) DEFAULT 'Pending', -- Pending, Completed, Failed, Cancelled
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (processed_by) REFERENCES Admins(admin_id) ON DELETE SET NULL,
    INDEX idx_payment_date (payment_date),
    INDEX idx_payment_type (payment_type),
    INDEX idx_status (status)
);

-- Revenue Tracking Table
CREATE TABLE Revenue (
    revenue_id INT PRIMARY KEY AUTO_INCREMENT,
    `date` DATE UNIQUE NOT NULL,
    total_sales DECIMAL(12, 2) DEFAULT 0,
    total_orders INT DEFAULT 0,
    expenses DECIMAL(12, 2) DEFAULT 0, -- Staff salaries, rent, etc.
    net_profit DECIMAL(12, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (`date`)
);

-- ===== COMPLAINT AND FEEDBACK TABLES =====

-- Complaint Types Reference Table
CREATE TABLE ComplaintTypes (
    type_id INT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT
);

INSERT INTO ComplaintTypes (type_name, description) VALUES
('Food Quality', 'Issues with food quality or freshness'),
('Late Delivery', 'Order not ready at specified time'),
('Missing Items', 'Items missing from order'),
('Wrong Order', 'Incorrect items in order'),
('Service Issue', 'Problem with service or staff'),
('Billing Issue', 'Payment or billing related problem'),
('Other', 'Other issues not listed above');

-- Complaints Table
CREATE TABLE Complaints (
    complaint_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    order_id INT,
    complaint_type_id INT NOT NULL,
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    attachment_url VARCHAR(255),
    status VARCHAR(50) DEFAULT 'Open', -- Open, In Progress, Resolved, Closed
    priority VARCHAR(50) DEFAULT 'Medium', -- Low, Medium, High
    resolved_by INT,
    resolution_notes TEXT,
    resolved_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE SET NULL,
    FOREIGN KEY (complaint_type_id) REFERENCES ComplaintTypes(type_id) ON DELETE RESTRICT,
    FOREIGN KEY (resolved_by) REFERENCES Admins(admin_id) ON DELETE SET NULL,
    INDEX idx_student_id (student_id),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_created_at (created_at)
);

-- Feedback Table (General feedback, not complaints)
CREATE TABLE Feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    order_id INT,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE SET NULL,
    INDEX idx_student_id (student_id),
    INDEX idx_created_at (created_at)
);

-- ===== NOTIFICATION TABLES =====

-- Notifications Table
CREATE TABLE Notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    notification_type VARCHAR(100), -- Order Ready, Order Cancelled, etc.
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    related_order_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (related_order_id) REFERENCES Orders(order_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
);

-- ===== AUDIT AND LOGGING TABLES =====

-- Activity Log Table
CREATE TABLE ActivityLog (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(200) NOT NULL,
    affected_table VARCHAR(100),
    affected_record_id INT,
    old_value JSON,
    new_value JSON,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
);

-- ===== INDEXES FOR PERFORMANCE =====

-- Additional performance indexes
CREATE INDEX idx_orders_date_status ON Orders(order_date, status_id);
CREATE INDEX idx_complaints_status_priority ON Complaints(status, priority);
CREATE INDEX idx_fooditems_category_rating ON FoodItems(category_id, rating DESC);

-- ===== VIEWS FOR REPORTING =====

-- View: Order Statistics by Student
CREATE VIEW vw_student_order_stats AS
SELECT 
    s.student_id,
    s.student_name,
    s.student_number,
    COUNT(o.order_id) as total_orders,
    SUM(o.total_amount) as total_spent,
    AVG(o.total_amount) as avg_order_value,
    MAX(o.created_at) as last_order_date
FROM Students s
LEFT JOIN Orders o ON s.student_id = o.student_id
GROUP BY s.student_id, s.student_name, s.student_number;

-- View: Daily Sales Report
CREATE VIEW vw_daily_sales_report AS
SELECT 
    DATE(o.created_at) as order_date,
    COUNT(DISTINCT o.order_id) as total_orders,
    COUNT(DISTINCT o.student_id) as unique_students,
    SUM(o.total_amount) as total_revenue,
    AVG(o.total_amount) as avg_order_value
FROM Orders o
WHERE o.status_id IN (5, 3, 4) -- Ready, Preparing, Confirmed
GROUP BY DATE(o.created_at)
ORDER BY order_date DESC;

-- View: Staff Performance
CREATE VIEW vw_staff_performance AS
SELECT 
    s.staff_id,
    s.staff_name,
    s.position,
    COUNT(DISTINCT o.order_id) as orders_prepared,
    COUNT(CASE WHEN o.status_id = 5 THEN 1 END) as orders_completed,
    AVG(TIMESTAMPDIFF(MINUTE, o.created_at, o.updated_at)) as avg_prep_time
FROM Staff s
LEFT JOIN Orders o ON s.staff_id <> 0 -- Placeholder for staff assignment
GROUP BY s.staff_id, s.staff_name, s.position;

-- View: Popular Food Items
CREATE VIEW vw_popular_food_items AS
SELECT 
    f.food_id,
    f.food_name,
    c.category_name,
    f.price,
    COUNT(od.order_detail_id) as times_ordered,
    SUM(od.quantity) as total_quantity_sold,
    f.rating
FROM FoodItems f
LEFT JOIN Categories c ON f.category_id = c.category_id
LEFT JOIN OrderDetails od ON f.food_id = od.food_id
GROUP BY f.food_id, f.food_name, c.category_name, f.price, f.rating
ORDER BY times_ordered DESC;

-- View: Unresolved Complaints
CREATE VIEW vw_unresolved_complaints AS
SELECT 
    c.complaint_id,
    c.subject,
    ct.type_name,
    s.student_name,
    c.priority,
    c.created_at,
    DATEDIFF(NOW(), c.created_at) as days_open
FROM Complaints c
INNER JOIN ComplaintTypes ct ON c.complaint_type_id = ct.type_id
INNER JOIN Students s ON c.student_id = s.student_id
WHERE c.status IN ('Open', 'In Progress')
ORDER BY c.priority DESC, c.created_at ASC;

COMMIT;
