-- Create test orders for demonstration
USE ewu_cafeteria_project;

-- ===== SAMPLE TEST ORDERS FOR STUDENTS =====

-- Insert test order 1 for Student One (Pending status)
INSERT INTO Orders (student_id, order_date, order_time, status_id, total_amount, payment_status, payment_method, special_instructions)
SELECT 
    student_id, 
    CURDATE(), 
    TIME(NOW()),
    1,  -- Pending status
    150.00,
    'Pending',
    'Cash',
    'Please add extra sauce'
FROM Students 
WHERE student_name = 'Student One'
LIMIT 1;

-- Insert test order 2 for Student One (Confirmed status)
INSERT INTO Orders (student_id, order_date, order_time, status_id, total_amount, payment_status, payment_method, special_instructions)
SELECT 
    student_id, 
    DATE_SUB(CURDATE(), INTERVAL 1 DAY), 
    '12:30:00',
    3,  -- Preparing status
    200.00,
    'Paid',
    'Card',
    'No onions please'
FROM Students 
WHERE student_name = 'Student One'
LIMIT 1;

-- Insert test order 3 for Student Two (Ready status)
INSERT INTO Orders (student_id, order_date, order_time, status_id, total_amount, payment_status, payment_method, special_instructions)
SELECT 
    student_id, 
    DATE_SUB(CURDATE(), INTERVAL 2 DAY), 
    '14:00:00',
    4,  -- Ready status
    180.00,
    'Paid',
    'Cash',
    'Extra spicy'
FROM Students 
WHERE student_name = 'Student Two'
LIMIT 1;

-- Insert test order 4 for Student Two (Picked Up status)
INSERT INTO Orders (student_id, order_date, order_time, status_id, total_amount, payment_status, payment_method, special_instructions)
SELECT 
    student_id, 
    DATE_SUB(CURDATE(), INTERVAL 3 DAY), 
    '13:15:00',
    5,  -- Picked Up status
    120.00,
    'Paid',
    'Card',
    NULL
FROM Students 
WHERE student_name = 'Student Two'
LIMIT 1;

-- ===== INSERT ORDER DETAILS =====

-- Get order ID for Student One's first order (most recent)
SET @order1_id = (
    SELECT order_id FROM Orders 
    WHERE student_id = (SELECT student_id FROM Students WHERE student_name = 'Student One' LIMIT 1)
    ORDER BY created_at DESC LIMIT 1
);

-- Insert order details for order 1
INSERT INTO OrderDetails (order_id, food_id, quantity, price_at_order)
VALUES 
    (@order1_id, 6, 1, 120.00),  -- Chicken Biryani
    (@order1_id, 3, 1, 20.00),   -- Chai & Biscuit
    (@order1_id, 19, 2, 15.00);  -- Samosa (2 units)

-- Get order ID for Student One's second order
SET @order2_id = (
    SELECT order_id FROM Orders 
    WHERE student_id = (SELECT student_id FROM Students WHERE student_name = 'Student One' LIMIT 1)
    ORDER BY created_at ASC LIMIT 1
);

-- Insert order details for order 2
INSERT INTO OrderDetails (order_id, food_id, quantity, price_at_order)
VALUES 
    (@order2_id, 8, 1, 90.00),   -- Chicken Curry with Rice
    (@order2_id, 29, 2, 30.00),  -- Lassi (2 units)
    (@order2_id, 20, 2, 10.00);  -- Pakora (2 units)

-- Get order ID for Student Two's first order (most recent)
SET @order3_id = (
    SELECT order_id FROM Orders 
    WHERE student_id = (SELECT student_id FROM Students WHERE student_name = 'Student Two' LIMIT 1)
    ORDER BY created_at DESC LIMIT 1
);

-- Insert order details for order 3
INSERT INTO OrderDetails (order_id, food_id, quantity, price_at_order)
VALUES 
    (@order3_id, 7, 1, 110.00),  -- Beef Biryani
    (@order3_id, 26, 1, 15.00),  -- Chai/Tea
    (@order3_id, 21, 1, 50.00);  -- Chicken Roll

-- Get order ID for Student Two's second order
SET @order4_id = (
    SELECT order_id FROM Orders 
    WHERE student_id = (SELECT student_id FROM Students WHERE student_name = 'Student Two' LIMIT 1)
    ORDER BY created_at ASC LIMIT 1
);

-- Insert order details for order 4
INSERT INTO OrderDetails (order_id, food_id, quantity, price_at_order)
VALUES 
    (@order4_id, 11, 1, 40.00);  -- Dal with Rice

-- ===== VERIFY TEST DATA =====

-- Check the orders now
SELECT o.order_id, o.student_id, s.student_name, o.status_id, os.status_name, o.total_amount, o.payment_status, o.created_at
FROM Orders o
JOIN OrderStatus os ON o.status_id = os.status_id
JOIN Students s ON o.student_id = s.student_id
ORDER BY o.created_at DESC;

-- Check order details
SELECT od.order_detail_id, od.order_id, od.food_id, f.food_name, od.quantity, od.price_at_order
FROM OrderDetails od
JOIN FoodItems f ON od.food_id = f.food_id
ORDER BY od.order_id DESC;